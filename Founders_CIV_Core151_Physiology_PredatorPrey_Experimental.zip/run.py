#!/usr/bin/env python3
"""Cycle151 launcher: regulated Core150 engine, no network or API key."""
from pathlib import Path
import os,subprocess,sys
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'Founders_CIV_CoreCompletion151'/'source'
env=dict(os.environ)
env['PYTHONHASHSEED']='0'
env['PYTHONPATH']=os.pathsep.join((str(SOURCE/'src'),str(SOURCE/'world023024'),str(SOURCE)))
if sys.version_info<(3,10):
    print('Python 3.10+ required',file=sys.stderr);sys.exit(2)
sys.exit(subprocess.run([sys.executable,str(SOURCE/'run_local_core151.py'),*sys.argv[1:]],cwd=ROOT,env=env).returncode)
