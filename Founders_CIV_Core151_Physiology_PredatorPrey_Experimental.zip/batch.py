#!/usr/bin/env python3
"""Run multiple deterministic seeds in independent Python processes."""
from pathlib import Path
import argparse,csv,json,os,subprocess,sys
ROOT = Path(__file__).resolve().parent
RUN = ROOT/'run.py'

def main():
    p=argparse.ArgumentParser(description='Run Core151 long-horizon comparisons on local machine.')
    p.add_argument('--days',type=int,default=360,help='Target day for each seed.')
    p.add_argument('--seeds',type=int,default=3,help='Number of independent seeds.')
    p.add_argument('--seed-start',type=int,default=100001)
    p.add_argument('--animals',type=int,default=68)
    p.add_argument('--report-every',type=int,default=30)
    p.add_argument('--checkpoint-every',type=int,default=90)
    p.add_argument('--output',default='results/batch_core151')
    p.add_argument('--stop-on-world-collapse',action='store_true')
    p.add_argument('--maintenance-factor',type=float,default=1.0)
    p.add_argument('--disable-predation',action='store_true')
    p.add_argument('--disable-regulated-foraging',action='store_true')
    p.add_argument('--disable-carrion-tracking',action='store_true')
    p.add_argument('--enable-intraguild-risk',action='store_true')
    p.add_argument('--disable-fuel-flex',action='store_true')
    p.add_argument('--disable-local-tracking',action='store_true')
    p.add_argument('--disable-mate-search',action='store_true')
    p.add_argument('--disable-trophic-diet',action='store_true')
    p.add_argument('--disable-trophic-hunting',action='store_true')
    p.add_argument('--disable-trophic-provisioning',action='store_true')
    p.add_argument('--disable-cleanup-150',action='store_true')
    a=p.parse_args()
    if not 1<=a.seeds<=1000 or not 1<=a.days<=50000:
        p.error('--seeds must be 1..1000 and --days must be 1..50000')
    output=Path(a.output).expanduser().resolve();output.mkdir(parents=True,exist_ok=True)
    rows=[]
    for seed in range(a.seed_start,a.seed_start+a.seeds):
        sub=output/f'seed_{seed}'
        summary=sub/'summary.json'
        prior=json.loads(summary.read_text()) if summary.exists() else None
        # Prevent accidental cross-arm contamination when rerunning a batch into
        # an existing output directory. The original runner silently skipped or
        # resumed a run performed under different physical/trophic settings.
        meta_path=sub/'run_metadata.json'
        if prior is not None:
            if not meta_path.exists():
                print(f'ERROR: seed {seed} has a summary but no configuration metadata; use a new --output folder.', file=sys.stderr)
                return 3
            meta=json.loads(meta_path.read_text())
            expected={
                'engine':'UnifiedRegulatedForaging151',
                'seed':seed,
                'initial_bridge_total':a.animals,
                'maintenance_factor':a.maintenance_factor,
                'predation_enabled':not a.disable_predation,
                'trophic_diet_enabled':not a.disable_trophic_diet,
                'trophic_hunting_enabled':not a.disable_trophic_hunting,
                'trophic_provisioning_enabled':not a.disable_trophic_provisioning,
                'fuel_flex_enabled':not a.disable_fuel_flex,
                'local_tracking_enabled':not a.disable_local_tracking,
                'mate_search_enabled':not a.disable_mate_search,
                'cleanup150_enabled':not a.disable_cleanup_150,
                'regulated_foraging_enabled':not a.disable_regulated_foraging,
                'carrion_tracking_enabled':not a.disable_carrion_tracking,
                'intraguild_risk_experimental':a.enable_intraguild_risk,
            }
            mismatched={key:(meta.get(key),value) for key,value in expected.items()
                        if meta.get(key)!=value}
            if mismatched:
                print(f'ERROR: seed {seed} has incompatible experiment settings: {mismatched}. '
                      f'Use a new --output folder per treatment.',file=sys.stderr)
                return 3
        achieved=(prior or {}).get('day_reached',0)
        if achieved >= a.days:
            print(f'Already complete seed {seed} day {achieved}; skipping',flush=True)
            rows.append({'seed':seed,'status':'already_complete','day':achieved,
                        'bridge_living':prior['final']['bridge_living'],
                        'native_living':prior['final']['native_living'],
                        'g2_births':prior['final']['g2_births_exact']})
            continue
        cmd=[sys.executable,str(RUN),'--days',str(a.days-achieved),
             '--report-every',str(a.report_every),
             '--checkpoint-every',str(a.checkpoint_every),'--output',str(sub),'--quiet']
        if a.stop_on_world_collapse:cmd.append('--stop-on-world-collapse')
        if not achieved:
            cmd += ['--maintenance-factor',str(a.maintenance_factor)]
            if a.disable_predation:cmd.append('--disable-predation')
            if a.disable_fuel_flex:cmd.append('--disable-fuel-flex')
            if a.disable_local_tracking:cmd.append('--disable-local-tracking')
            if a.disable_mate_search:cmd.append('--disable-mate-search')
            if a.disable_trophic_diet:cmd.append('--disable-trophic-diet')
            if a.disable_trophic_hunting:cmd.append('--disable-trophic-hunting')
            if a.disable_trophic_provisioning:cmd.append('--disable-trophic-provisioning')
            if a.disable_cleanup_150:cmd.append('--disable-cleanup-150')
            if a.disable_regulated_foraging:cmd.append('--disable-regulated-foraging')
            if a.disable_carrion_tracking:cmd.append('--disable-carrion-tracking')
            if a.enable_intraguild_risk:cmd.append('--enable-intraguild-risk')
        if achieved and (sub/'latest_checkpoint.pkl').exists():
            cmd += ['--resume',str(sub/'latest_checkpoint.pkl')]
        else:
            cmd += ['--seed',str(seed),'--animals',str(a.animals)]
        print(f'Running seed {seed}, starting day {achieved}, target {a.days}',flush=True)
        result=subprocess.run(cmd,cwd=ROOT)
        if result.returncode:
            print(f'Seed {seed} failed with exit {result.returncode}; see folder {sub}',file=sys.stderr)
            return result.returncode
        end=json.loads(summary.read_text())
        f=end['final']
        rows.append({'seed':seed,'status':end['status'],'day':end['day_reached'],
                    'bridge_living':f['bridge_living'],'native_living':f['native_living'],
                    'g2_births':f['g2_births_exact']})
        with (output/'batch_summary.csv').open('w',newline='') as stream:
            w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('Saved:',output/'batch_summary.csv',flush=True)
    return 0

if __name__=='__main__':sys.exit(main())
