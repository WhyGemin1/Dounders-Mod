"""Matched-seed ecological stress runner for Core150 vs Core151.

Evidence counters are derived from unchanged engine events/Book. This script
adds no simulation mechanisms, observations, or survival protections.
"""
from pathlib import Path
from collections import Counter
import argparse,csv,json,sys,time
P=Path(__file__).resolve().parent
S=P/'Founders_CIV_CoreCompletion151'/'source'
sys.path[:0]=[str(S/'src'),str(S/'world023024'),str(S)]
from integration_cleanup_150 import UnifiedCleanup150
from unified_foraging_151 import UnifiedRegulatedForaging151
from trophic_roles_146 import CARNIVORE_ROLES
from species_life_02115 import PROFILES

PREY=['field_mouse','meadow_grazer','forest_browser','burrow_rabbit','field_vole','ant_colony','forest_elephant','woolly_mammoth']
PRED=['ridge_hound','red_fox','golden_jackal','insectivore_shrew','carrion_bird']

def snapshot(s, seed, arm):
 b=s.bridge;book=s.host.book
 living=[a for a in b.actors.values() if a.alive]
 count=Counter(a.species for a in living)
 deaths=Counter(e.get('cause') for e in b.events if e.get('event')=='death')
 kills=Counter(b.actors[e['predator']].species for e in b.events if e.get('event')=='predation' and e.get('predator') in b.actors)
 female=Counter(a.species for a in living if a.stage=='adult' and a.sex=='F')
 male=Counter(a.species for a in living if a.stage=='adult' and a.sex=='M')
 report=s.report()
 traits=Counter()
 for a in living:
  if a.species in PRED:
   traits['stored_pred_energy']+=book.energy[b.physical.reserve(a)]
   traits['gut_pred_energy']+=book.energy[b._gut_energy(a)]
   traits['short_pred_energy']+=book.energy[b._short(a)]
 audit=book.audit()
 row=dict(seed=seed,arm=arm,day=s.days,bridge_alive=len(living),
          native_alive=b.tree.population,world=b.tree.state,
          predator_alive=sum(count[p] for p in PRED), prey_alive=sum(count[p] for p in PREY),
          viable_prey_species=sum(bool(male[x] and female[x]) for x in PREY if x!='ant_colony'),
          g1_births=sum(a.generation==1 for a in b.actors.values()),
          g2_births=sum(a.generation==2 for a in b.actors.values()),
          g3plus_births=sum(a.generation>=3 for a in b.actors.values()),
          physiological_deaths=deaths['physiological_failure'],
          predation_deaths=deaths['predation'],
          all_predator_kills=sum(kills.values()),
          kill_hound=kills['ridge_hound'],
          kill_fox=kills['red_fox'],kill_jackal=kills['golden_jackal'],
          rejected_book=audit['rejections'],
          energy_error=audit['energy_error'],mass_error=audit['mass_error'],
          completed_meals=b.physiology_metrics['paired_lot_meals'],
          **traits)
 for species in sorted(PROFILES):
  row['alive_'+species]=count[species]
  row['G2_'+species]=sum(a.generation==2 and a.species==species for a in b.actors.values())
 if hasattr(b,'regulation151_metrics'):
  row.update({('policy_'+name):v for name,v in b.regulation151_metrics.items()})
 return row

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--seed',type=int,default=100001)
 parser.add_argument('--days',type=int,default=180)
 parser.add_argument('--arm',choices=['Core150','Core151','no-predation'],default='Core151')
 parser.add_argument('--output',required=True)
 parser.add_argument('--disable-carrion-tracking',action='store_true')
 parser.add_argument('--prey-rich',action='store_true',help='Scenario: fund 14 initial rabbits and 14 voles instead of 8 each')
 parser.add_argument('--checkpoints',default='30,60,90,120,180,360,720')
 args=parser.parse_args()
 ctor=UnifiedCleanup150 if args.arm=='Core150' else UnifiedRegulatedForaging151
 kwargs={'predation':False} if args.arm=='no-predation' else {}
 if args.prey_rich:
  from trophic_guilds_cycle138 import GUILD_FOUNDERS
  guild=dict(GUILD_FOUNDERS)
  guild.update(burrow_rabbit=14,field_vole=14)
  kwargs['guild_counts']=guild
 if ctor is UnifiedRegulatedForaging151: kwargs['carrion_tracking']=not args.disable_carrion_tracking
 sim=ctor(seed=args.seed,**kwargs)
 checkpoints=sorted({d for d in (int(x) for x in args.checkpoints.split(',')) if d<=args.days and d>0}|{args.days})
 rows=[];start=time.monotonic()
 for day in checkpoints:
  sim.run(day-sim.days)
  row=snapshot(sim,args.seed,args.arm)
  row['elapsed_seconds']=round(time.monotonic()-start,2)
  rows.append(row)
  print(args.arm,args.seed,day,'living',row['bridge_alive'],'hounds',row['alive_ridge_hound'],'foxes',row['alive_red_fox'],'jackals',row['alive_golden_jackal'],'prey',row['prey_alive'],'kills',row['all_predator_kills'],'G2',row['g2_births'],'phys',row['physiological_deaths'],flush=True)
  target=Path(args.output)
  target.parent.mkdir(parents=True,exist_ok=True)
  keys=list(dict.fromkeys(k for r in rows for k in r))
  with target.open('w',newline='') as f:
   w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)
 (Path(args.output).with_suffix('.json')).write_text(json.dumps(rows[-1],indent=2))

if __name__=='__main__':main()
