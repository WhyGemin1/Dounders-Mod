# Founders–CIV Core151 — desktop runner

1. Extract the entire ZIP to a folder. Install **Python 3.10+** (no ChatGPT or API key needed).
2. On Windows, double-click `Run_Windows.bat`; on Mac/Linux run `sh Run_Mac_Linux.sh`. Both launch an interactive setup.
3. Or open Terminal in the extracted folder and run:

```bash
python run.py --days 360 --animals 68 --seed 100001 --output results/regulation
```

Matched old-engine comparison (same seed and count, SEPARATE output folder):

```bash
python run.py --days 360 --animals 68 --seed 100001 --disable-regulated-foraging --output results/core150_control
```

Alternative controls:

```bash
python run.py --days 360 --animals 68 --seed 100001 --disable-carrion-tracking --output results/no_carrion_tracking
python run.py --days 360 --animals 68 --seed 100001 --enable-intraguild-risk --output results/intraguild_trial
```

**Note:** `--enable-intraguild-risk` is a failed/inconclusive experimental arm, not recommended for routine use. All physical resources remain Book-funded. 100 Founders are fixed, and `--animals` configures only bridge animals. The original five species require at least 8 founding animals each due the family initializer. Use `python run.py --list-species` for all 13 species.

Longer runs and resume:

```bash
python run.py --days 1080 --animals 68 --seed 100001 --checkpoint-every 90 --output results/longrun
python run.py --resume results/longrun/latest_checkpoint.pkl --days 360 --output results/longrun
python batch.py --days 360 --seeds 3 --animals 68 --output results/batch
```

The `--days` argument on resume is **additional** time after the checkpoint. Use only checkpoints created by your own run: pickle is unsafe to load from untrusted sources.

Tests from the project source folder, with `PYTHONPATH` including `src`, `world023024`, and source root:

```bash
cd Founders_CIV_CoreCompletion151/source
PYTHONPATH=src:world023024:. python -m unittest -q test_regulated_foraging_151
```

Simulation results include timeline CSV, traits CSV, metadata JSON, summary JSON, and resumable pickle. Synthetic physiology is still experimental; this is not a validated ecological game engine.
