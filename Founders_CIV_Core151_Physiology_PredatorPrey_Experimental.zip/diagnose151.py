from pathlib import Path
from collections import Counter
import argparse,csv,sys
P=Path(__file__).resolve().parent; S=P/'Founders_CIV_CoreCompletion151'/'source'
sys.path[:0]=[str(S/'src'),str(S/'world023024'),str(S)]
from unified_foraging_151 import UnifiedRegulatedForaging151
from trophic_guilds_cycle138 import GUILD_FOUNDERS
from core_physiology_v2 import PREY
from trophic_roles_146 import CARNIVORE_ROLES

p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=100001);p.add_argument('--days',type=int,default=280);p.add_argument('--prey-rich',action='store_true');p.add_argument('--disable-carrion-tracking',action='store_true');p.add_argument('--output',required=True);args=p.parse_args()
guild=dict(GUILD_FOUNDERS)
if args.prey_rich:guild.update(burrow_rabbit=14,field_vole=14)
sim=UnifiedRegulatedForaging151(seed=args.seed,guild_counts=guild,carrion_tracking=not args.disable_carrion_tracking)
br=sim.bridge;book=sim.host.book;original=br._death;rows=[]
def track(animal,cause):
 if animal.alive and animal.species in CARNIVORE_ROLES:
  same=[x for x in br.actors.values() if x.alive and x.habitat==animal.habitat and x.species in PREY.get(animal.species,())]
  pos=br._pos(animal)
  nearby=sum(abs(br._pos(x)[1]-pos[1])+abs(br._pos(x)[2]-pos[2])<=1 for x in same)
  patch=[(k,m) for k,m in br._carcass_patches149.items() if k[0]==animal.habitat and m>1e-6]
  ph=br.physical
  rows.append(dict(day=br.day,species=animal.species,stage=animal.stage,cause=cause,
     mass=book.mass[ph.live(animal)],short=book.energy[br._short(animal)],
     reserve=book.energy[ph.reserve(animal)],gut_energy=book.energy[br._gut_energy(animal)],
     gut_mass=book.mass[ph.gut(animal)],tissue_energy=book.energy[ph.tissue(animal)],
     fatigue=br._state(animal).fatigue,readiness=br._state(animal).readiness,
     prey_same_habitat=len(same),prey_in_strike_range=nearby,
     carrion_mass_in_habitat=book.mass[br.carrion(animal.habitat)],
     distinct_carcass_patches=len(patch),hounds_alive=sum(a.alive and a.species=='ridge_hound' for a in br.actors.values())))
 return original(animal,cause)
br._death=track
for step in range(args.days):
 sim.step()
 if sim.days in (60,120,180,240,args.days):
  living=Counter(a.species for a in br.actors.values() if a.alive)
  print(sim.days,'hound',living['ridge_hound'],'fox',living['red_fox'],'jackal',living['golden_jackal'],'rabbit',living['burrow_rabbit'],'vole',living['field_vole'],'unfunded',br.physiology_metrics['work_unfunded'],flush=True)
pth=Path(args.output);pth.parent.mkdir(exist_ok=True,parents=True)
if rows:
 with pth.open('w',newline='') as f:
  w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
 print('deaths',len(rows),'saved',pth,flush=True)
else:print('no predator deaths',flush=True)
