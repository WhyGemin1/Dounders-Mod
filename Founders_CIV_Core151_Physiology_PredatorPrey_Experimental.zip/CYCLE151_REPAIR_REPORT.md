# Founders–CIV Core151 — physiological feeding and predator–prey repair audit

**Source:** direct copy of the Core150 working engine with one opt-out Core151 integration service. **Status:** experimental only. 100 canonical Founders, 13 bridge-animal species, 1 World Tree Book and 1 World clock; the two demographic schedulers remain separate.

## Four implementation and validation phases

1. **Audit the competing pathways.** Followed Core146 hunting/satiation through Core148 spatial tracking, Core149 kill food and carcass preference, and Core150 local paired energy. Confirmed separate decisions could initiate hunting despite adequate body stores, while food search and consumption were inconsistently prioritized. The source's old starvation-debt score independently triggered death at 0.98, even when condition and embodied tissue energy were not critically depleted.
2. **Build one physiological resolver.** `src/unified_foraging_151.py` evaluates gut mass and embodied energy, circulating fuel, stored reserves, actual maintenance demand, current need, and reachable carcass food in the same rule for deciding whether to feed and whether a strike is permitted. Rest and digestion require no artificial energy/time credit. Added Book-funded, one-cell carrion tracking (with no instantaneous strike after the step).
3. **Correct genuine inability-to-work and premature-death mechanics.** The death trace found hounds dying with many prey in the same habitat and tissue energy still present. Core151 permits bounded tissue-to-circulating energy transfer for an actual, nearby high-intensity strike, with physical body-mass loss, heat, and reduced condition. Fatal starvation now depends on true critical condition or severe physical body/fuel depletion, not starvation-debt score alone. The original rule remains exactly available when Core151 is disabled.
4. **Run matched comparisons and isolate failures.** Tested two matched 180-day seeds, one 360-day reference seed, a 360-day prey-rich scenario, and a risk-based intraguild-predation experiment. 88 selected focused/inherited automated tests pass. Risk-based intraguild avoidance was inconclusive/harmful in matched comparisons and was **left OFF by default**; it is an optional experiment, not an approved repair.

## Matched 180-day results — 68 initial bridge animals

| Measure | Seed 100001 Core150 | Seed 100001 Core151 | Seed 100002 Core150 | Seed 100002 Core151 |
|---|---:|---:|---:|---:|
| Living bridge animals | 50 | 56 | 44 | 43 |
| Ridge hounds | 5 | 8 | 3 | 9 |
| Red foxes | 0 | 1 | 1 | 2 |
| Golden jackals | 0 | 1 | 0 | 0 |
| Living prey | 30 | 32 | 33 | 20 |
| Physiological deaths | 12 | 2 | 10 | 1 |
| Successful predator kills | 28 | 28 | 21 | 35 |
| Book rejections | 0 | 0 | 0 | 0 |

The treatment reduces physiological deaths strongly, particularly in seed 100001, and preserves additional hounds. But seed 100002 has more kills and fewer prey; ecological balance is **not** demonstrated.

## Day 360: persistent predator failure under canonical founding cohort

| Measure | Core150 seed 100001 | Core151 seed 100001 | Core151 prey-rich scenario |
|---|---:|---:|---:|
| Initial animal cohort | 68 | 68 | 80 (14 rabbits and 14 voles rather than 8 each) |
| Living animals | 67 | 57 | 98 |
| Ridge hounds | 0 | 0 | 6 |
| Red foxes | 0 | 0 | 2 |
| Golden jackals | 0 | 0 | 0 |
| Prey alive | 54 | 47 | 78 |
| G2 births | 24 | 13 | 53 |
| Physiological deaths | 18 | 12 | 6 |
| Predator kills | 28 | 33 | 100 |

**Critical caveat:** The 80-animal comparison alters actual predator/prey starting ratios and is a **scenario sensitivity test**, not an isolated causal comparison of algorithms. Both the reference World and richer World were Book-funded; no species was protected from legitimate mortality. The richer ecosystem still lost its jackals.

## Remaining engineering blockers

- Predation and prey recruitment are not self-regulating across all species. The original eight ridge-hound founding animals can place extreme initial pressure on a relatively small prey base. The upstream family initializer requires **four founding pairs of each original species**, so the runner cannot simply request two hounds without further architectural work.
- Jackals and foxes may be removed by direct intraguild kills before reproduction; the old kill pathway directly marks `victim.alive=False` and does not use the ordinary `_death` callback. A new risk-aversion intervention was tested but did not consistently help and remains off by default.
- The new short-term rescue improves the physical meaning of fuel access, but synthetic calories, body composition, protein/micro-nutrition, prey encounter success and rate-based movement still require independent empirical calibration.
- 30-seed/720-day/1080-day full life-cycle acceptance, all 13 species G2 recruitment, all carnivore persistence, native-resident long-horizon viability, and realistic trophic density are **not passed**.

## Source entry points

- `run.py`: portable default launcher and experiment controls.
- `Founders_CIV_CoreCompletion151/source/src/unified_foraging_151.py`: unified physiological policy and physically funded fuel repairs.
- `Founders_CIV_CoreCompletion151/source/src/five_phase_core_142.py`: narrow virtual failure hook; historic default retained for exact control.
- `Founders_CIV_CoreCompletion151/source/test_regulated_foraging_151.py`: 11 direct focused tests including Book conservation, actual fuel-limited strike, exact off-control, checkpoint replay and risk ablation.
- `stress151.py`: matched-seed comparison runner; `diagnose151.py`: predator failure tracing.
- `STRESS151_MATCHED_RESULTS.csv`: explicit samples and arms.

**Release decision: Core151 experimental, Core150 comparison preserved.** This cycle **repairs premature physiological failure and competing feeding decisions**, but does not prove that predators can persist without exhausting prey in the canonical 68-animal reference system.
