@echo off
cd /d "%~dp0"
python -m unittest discover -s tests -q
if errorlevel 1 (echo Suite 1 failed. & exit /b 1)
python -m unittest discover -s . -p "test*.py" -q
if errorlevel 1 (echo Suite 2 failed. & exit /b 1)
python run_integration_025.py examples\scenarios\commons.json --check-hashes --out results\integration_025\commons.json
if errorlevel 1 (echo Compatibility smoke failed. & exit /b 1)
echo All integration tests completed.
