# Founders-CIV v0.16 — Pre-Integration Optimization Branch

**Status:** Executable, separately tested prototype modules; **NOT** an integrated v0.16 simulation. No changes were made to the original v0.12, v0.13 or v0.14 files. Standard-library Python 3.10+.

## Windows quick start

Unzip the package, open Windows Terminal in the `founders_preintegration_v016` folder, then run:

```powershell
py -m unittest -v test_preintegration
py run_preflight.py --quick
py run_preflight.py
py benchmark_preintegration.py
```

On macOS/Linux substitute `python3` for `py`. Test output is written to `pilot_outputs/`. Avoid running the legacy engines' `main()` to keep results from being written outside this branch.

## Included code

- `founders_v012.py`: conserved core ecology with per-run species configuration, cached local actor index, O(1) actor lookup, and rolling successful-event memory counts.
- `founders_v013_species.py`: specialized species and predator mechanics with deterministic species iteration, isolated species profiles, patch-local lookups, and corrected migration feedback. `Sim(...,fix_migration=False)` is the **legacy compatibility switch** for output comparison only.
- `founders_v014_rsw_experiment.py`: RSW engine with shared immutable action-scoring constants and per-decision needs caching, preserving output behavior.
- `transaction_preflight.py`: standalone atomic transfer/transition contract with source-funded work, transformation-only toll and Wellspring external inflow.
- `social_preflight.py`: standalone directed learning sandbox with information sources, trust, exposures and practice records.
- `test_preintegration.py`: 17 automated checks across accounting, reproducibility, migration, social learning, engine golden cases and cross-run isolation.
- `run_preflight.py`: the isolated ecology, RSW, social diffusion and atomic-ledger pilots. Not a full factorial study.
- `benchmark_preintegration.py`: repeatable performance measurements for optimized engines.
- `pilot_outputs/*`: the preflight's exact observed results and benchmark comparisons.
- `baseline_base.json`, `baseline_rsw.json`: fixed golden result fixtures for short runs of the unmodified historical engines. These are used for behavioral-regression checks.

## Optimization details

| Change | Purpose | Semantics |
|---|---|---|
| Cache animal and creation lists by patch/species, invalidate after migration/spawn/death | Avoid repeatedly scanning the entire actor population | Same selection order for RNG choices |
| Track successful events within actor's 40-event history in a rolling counter | Avoid scanning the entire memory deque on each action | Equivalent threshold behavior |
| Cache each actor's current need state once for each action-selection cycle | Avoid recalculating identical needs 14 times | Exact v0.14 golden-output parity |
| Hoist action effects / conviction mappings into module constants | Avoid allocating dictionaries in every action score | Exact v0.14 golden-output parity |
| Use instance-scoped, deep-copied species profiles | Stop experimental modes contaminating each other | Deliberate correctness fix |
| Sort unordered species iteration during animal culture | Restore determinism across Python hash-seed environments | Deliberate randomness-order correction |
| Train migration route on the *selected* destination | Eliminate use of last-scanned destination's resources | Deliberate correctness fix |

## Testing and interpretation

The `run_preflight.py` default executes 6 ecology experiments (each containing 2 worlds), 12 RSW experiments, 15 social diffusion experiments, and 3 ledger stress tests of 5,000 attempted transactions. These synthetic pilots evaluate code paths, not external ecological or sociological validity.

The original and optimized **v0.12** and **v0.14** benchmark results match exactly. **v0.13 intentionally differs** because sorting culture transmission and correcting route feedback change some random-number use and decisions. For comparison against the original, use `fix_migration=False` *and* `PYTHONHASHSEED=0` with the pre-sorting build; the intermediate pre-sorting optimized version was verified to reproduce the original exactly. The final branch defaults to correct, hash-stable behavior.

`transaction_preflight.py` is a separate **single-abstract-material** ledger, not a chemistry engine or a full physical implementation of the universe. The older v0.14 RSW code still lacks comprehensive elemental and energy conservation. No v0.16 factorial arm has been executed here.

## Integration blockers (known)

1. The ecological engine still uses `spend(state=True)` as a default for many activities. In the final shared event system, tolls must be triggered only by *explicit material-state transformations*, not by moving or changing ownership itself. Where metabolic fuel changes state, it needs its own registered transaction rather than an unqualified movement toll.
2. The legacy v0.14 implementation gives a multiplier to collaborative work from aggregate `trust_index` and a shared norm. Replace it with actual worker participation, work inputs, tools, and group organization before attributing changes to RSW.
3. The old social code lacks directed family/friend/neighbor/teacher relationships, actor-specific information sources and explicit belief revision. `social_preflight.py` is a small independent prototype of the target interface, not a drop-in replacement for v0.14.
4. Institutions in legacy engines still arise from action counts or support thresholds. They need actual members, practices, resources, governance, and continuity.
5. The ecological model's toy element shares and plant/animal energy states are synthetic; the new atomic ledger must eventually replace direct mutations in the core before energy/material integrity can be audited across systems.
6. Ecological persistence across generations, hunter/prey balance and family-based species development are **not calibrated**. Short pilot survival is not a proof of stable ecological dynamics.
7. The fully independent four-factor `S/F/B/I` interface and frozen 480-run manifest require the systems to be combined and audited. This preflight is deliberately conducted before that step.

## Next integration gate

Only merge subsystems behind a single event/transaction interface after confirming: (1) no unregistered material or energy changes; (2) no skill gain without practice or accepted evidence; (3) all social information carries a source; (4) institution creation has identifiable participants and actual operations; (5) no free productivity from belief/legitimacy; (6) stable deterministic initial conditions and separate random streams; (7) negative tests fail when invariants are deliberately violated. Then run 2-day, 30-day and 120-day integrated *smoke* tests before the registered 720-day factorial experiment.
