"""Standalone directed-relationship and source-tagged learning preflight.

Not yet coupled to the ecological/RSW engines. Synthetic teaching probabilities.
Contrasts isolated, family, and diverse peer+mentor networks with matched starts.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from collections import defaultdict, Counter
import random

@dataclass
class Learner:
    id:int
    confidence:dict[str,float]=field(default_factory=dict)
    exposures:list[tuple[int,int,str]]=field(default_factory=list)
    practiced:dict[str,int]=field(default_factory=lambda:defaultdict(int))
    skill:dict[str,float]=field(default_factory=lambda:defaultdict(float))

@dataclass(frozen=True)
class Relation:
    source:int
    target:int
    category:str
    trust:float

class SocialPilot:
    def __init__(self, topology='diverse',seed=1,n=36):
        if topology not in ('isolated','family','diverse'):raise ValueError(topology)
        self.topology=topology;self.seed=seed;self.rng=random.Random(seed);self.day=0
        self.people=[Learner(i) for i in range(n)]
        self.relations=[];self.messages=[];self.practice_events=[]
        # Initial knowledge is *only* possessed by two source actors.
        self.people[0].confidence['safe_route']=.99
        self.people[18].confidence['unsafe_route']=.99
        if topology!='isolated':
            for src in range(n):
                for tgt in range(n):
                    if src!=tgt and src//6==tgt//6:
                        self.relations.append(Relation(src,tgt,'family',.78))
        if topology=='diverse':
            for src in range(n):
                # Neighbor across household boundaries, mentoring by experienced actor 0.
                for tgt in ((src+6)%n,(src-6)%n):
                    if src!=tgt:self.relations.append(Relation(src,tgt,'neighbor',.38))
            for tgt in range(3,n,6):
                if tgt!=0:self.relations.append(Relation(0,tgt,'mentor',.87))
        self.in_edges=defaultdict(list)
        for edge in self.relations:self.in_edges[edge.target].append(edge)

    def step(self):
        self.day+=1
        # Snapshot messages before applying new beliefs. No instant chain broadcast.
        incoming=[]
        for receiver in self.people:
            edges=self.in_edges[receiver.id]
            if not edges:continue
            edge=self.rng.choice(edges)
            source=self.people[edge.source]
            if not source.confidence:continue
            claim=max(source.confidence,key=source.confidence.get)
            level=source.confidence[claim]
            if level<.5:continue
            # Trust controls encounter acceptance, not objective correctness.
            if self.rng.random()<edge.trust*.55:
                incoming.append((receiver.id,edge.source,claim,edge.trust))
        for recipient,sender,claim,trust in incoming:
            person=self.people[recipient]
            new_conf=min(.99,person.confidence.get(claim,0)+.20+.12*trust)
            person.confidence[claim]=new_conf
            person.exposures.append((self.day,sender,claim))
            self.messages.append((self.day,sender,recipient,claim))
        # Practice is separate from the arrival or acceptance of information.
        for person in self.people:
            if person.confidence.get('safe_route',0)>.5 and person.exposures and self.rng.random()<.13:
                person.practiced['safe_route']+=1
                person.skill['safe_route']=min(1,person.skill['safe_route']+.045)
                self.practice_events.append((self.day,person.id,'safe_route'))

    def run(self,days=60):
        for _ in range(days):self.step()
        def count(claim):return sum(a.confidence.get(claim,0)>.50 for a in self.people)
        assert all(a.skill['safe_route']<=a.practiced['safe_route']*.045+1e-8 for a in self.people)
        assert all(a.skill['safe_route']==0 for a in self.people if a.practiced['safe_route']==0)
        assert all(a.confidence.get('safe_route',0)==0 for a in self.people[1:] if not a.exposures)
        return {'seed':self.seed,'topology':self.topology,'days':days,
                'correct_claim_adopters':count('safe_route'),
                'false_claim_adopters':count('unsafe_route'),
                'trained_actors':sum(a.skill['safe_route']>0 for a in self.people),
                'practice_events':len(self.practice_events), 'messages':len(self.messages),
                'distinct_teachers':len(set(sender for day,sender,recipient,claim in self.messages))}

if __name__=='__main__':
    for k in ('isolated','family','diverse'):
        print(SocialPilot(k).run())
