"""Benchmark the three isolated engines in this bundle; no integration."""
import statistics,time,json,argparse
from pathlib import Path
import founders_v012 as base
import founders_v013_species as eco
import founders_v014_rsw_experiment as rsw

def run(repeats=3):
    results={}
    cases={
      'core_v012_60d': lambda:base.Simulation(seed=12011,days=60,logs=False).run(),
      'species_v013_90d':lambda:eco.Sim('combined',seed=12011,days=90,logs=False).run(),
      'rsw_v014_120d': lambda:rsw.World('C',seed=12011,days=120,log=False).run(),
    }
    for name,make in cases.items():
        times=[]
        for i in range(repeats):
            begin=time.perf_counter();make();times.append(time.perf_counter()-begin)
        results[name]={'repeats':repeats,'mean_s':statistics.mean(times),'runs_s':times}
    return results

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repeats',type=int,default=3)
    p.add_argument('--out',type=Path,default=Path(__file__).parent/'pilot_outputs'/'benchmark_optimized.json')
    x=p.parse_args();x.out.parent.mkdir(parents=True,exist_ok=True)
    r=run(x.repeats);x.out.write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
