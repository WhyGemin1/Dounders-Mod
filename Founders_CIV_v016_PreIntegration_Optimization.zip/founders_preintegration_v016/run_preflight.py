#!/usr/bin/env python3
"""Run *isolated* canonical engine pilots, not the v0.16 factorial integration.

Modes: ecology species ablation, RSW control, directed social learning,
atomic transaction ledger. All simulations seeded, original assumptions synthetic.
"""
import argparse,csv,json,hashlib,statistics,time,sys
from pathlib import Path
import founders_v013_species as eco
import founders_v014_rsw_experiment as rsw
from social_preflight import SocialPilot
from transaction_preflight import run_stress

def csv_write(path,rows):
    if not rows:return
    with open(path,'w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=rows[0].keys());wr.writeheader();wr.writerows(rows)

def execute(out:Path,quick=False):
    out.mkdir(parents=True,exist_ok=True)
    eco_seeds=[12011,12043] if quick else [12011,12043,12071]
    rsw_seeds=[1,2] if quick else [1,2,3]
    social_seeds=[1,2,3] if quick else [1,2,3,4,5]
    eco_days=75 if quick else 120
    rsw_days=110 if quick else 150
    rows={'ecology':[],'rsw':[],'social':[],'ledger':[]}
    start=time.perf_counter()
    for seed in eco_seeds:
        for mode in ('baseline','combined'):
            s=eco.Sim(mode,seed,eco_days,False)
            t=time.perf_counter();r=s.run()
            if r['energy_error_max']>1e-5 or r['mass_error_max']>1e-5:raise AssertionError('ecology conservation failed')
            for world,w in r['worlds'].items():
                rows['ecology'].append({'seed':seed,'mode':mode,'days':eco_days,'world':world,
                    'prey':sum(w['species_counts'][x] for x in eco.HERBS),
                    'predators':sum(w['species_counts'][x] for x in eco.PREDS),
                    'scavengers':sum(w['species_counts'][x] for x in eco.SCAVS),
                    'plants':round(w['plants_final'],3),
                    'hunts':sum(w['species_hunts'][x]['attempts'] for x in eco.PREDS),
                    'hunt_wins':sum(w['species_hunts'][x]['wins'] for x in eco.PREDS),
                    'energy_error_max':r['energy_error_max'],'mass_error_max':r['mass_error_max']})
    for seed in rsw_seeds:
        for mode in ('A','B','C','C_false'):
            s=rsw.World(mode,seed,rsw_days,False)
            r=s.run()
            rows['rsw'].append({k:v for k,v in r.items() if k!='action_counts'})
    for seed in social_seeds:
        for topology in ('isolated','family','diverse'):
            rows['social'].append(SocialPilot(topology,seed).run(60))
    for seed in (12,42,1729):rows['ledger'].append(run_stress(seed,5000))
    for k in ('ecology','rsw','social'):csv_write(out/f'{k}_pilot.csv',rows[k])
    (out/'ledger_pilot.json').write_text(json.dumps(rows['ledger'],indent=2))
    # Repeated-seed deterministic test across independent instances.
    a=eco.Sim('combined',12011,50,False).run()
    b=eco.Sim('combined',12011,50,False).run()
    if a!=b:raise AssertionError('ecology reproducibility failed')
    a=rsw.World('C',1,60,False).run()
    b=rsw.World('C',1,60,False).run()
    if a!=b:raise AssertionError('RSW reproducibility failed')
    report={'status':'preintegration isolated pilot complete','not_integrated':True,
        'scope':{'ecology_runs':len(eco_seeds)*2,'eco_days':eco_days,'ecology_world_observations':len(rows['ecology']),
                 'rsw_runs':len(rows['rsw']),'rsw_days':rsw_days,'social_runs':len(rows['social']),
                 'transaction_attempts':15000},
        'ecology_mean_by_mode':{},'rsw_mean_by_mode':{},'social_mean_by_topology':{},
        'transaction_audit':rows['ledger'], 'determinism':'repeat-seed checks passed',
        'elapsed_s':round(time.perf_counter()-start,2)}
    for mode in ('baseline','combined'):
        rr=[x for x in rows['ecology'] if x['mode']==mode]
        report['ecology_mean_by_mode'][mode]={k:round(statistics.mean(r[k] for r in rr),3) for k in ('predators','prey','scavengers','plants','hunts','hunt_wins')}
    for mode in ('A','B','C','C_false'):
        rr=[x for x in rows['rsw'] if x['mode']==mode]
        report['rsw_mean_by_mode'][mode]={k:round(statistics.mean(r[k] for r in rr),2) for k in ('scarcity_actor_days','mean_health','mean_hunger','shared_rituals')}
    for topology in ('isolated','family','diverse'):
        rr=[x for x in rows['social'] if x['topology']==topology]
        report['social_mean_by_topology'][topology]={k:round(statistics.mean(r[k] for r in rr),2) for k in ('correct_claim_adopters','false_claim_adopters','trained_actors','messages')}
    (out/'preflight_summary.json').write_text(json.dumps(report,indent=2))
    return report

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path(__file__).parent/'pilot_outputs')
    ap.add_argument('--quick',action='store_true')
    args=ap.parse_args()
    print(json.dumps(execute(args.out,args.quick),indent=2))
