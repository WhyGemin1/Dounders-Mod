# Founders-CIV v0.16 — Four-Factor Operational Experiment

**Study ID:** `FCIV-016-4F-30S-720D`  
**Status:** designed and manifest generated; **not executed**.  
**Blueprint source:** `Founders_CIV_v016_Integration_Blueprint.md` (SHA-256 `b68be328757a946fa164a21f45e3d88631c5ac11bf716b26dabc21a85e59e21d`).

## 1. Purpose and preregistered causal question

Test whether richer social relationships (**S**), private Fear Logic and spiritual commitment (**F**), collective belief formation (**B**), and institutional monitoring and feedback (**I**) independently and jointly affect a society's response to drought and competing information. None of these mechanisms is assumed beneficial. We will distinguish beneficial coordination from misinformation, conformity, resource capture, and the displacement of practical work.

A 2×2×2×2 full factorial produces **16 arms**. All 16 run once on each of **30 matched base seeds**, for **480 total runs**, at **720 daily ticks per run**. Every arm on one seed shares initial actors, kin structure, hidden starting affinity potentials, habitat stocks, drought timing, weather, and initial misinformation sources.

**No v0.16 480-run experiment has been executed.** This package is the complete run design and preflight validator.

## 2. Four independent experimental factors

| Factor | 0 (control) | 1 (treatment) | Forbidden shortcut |
|---|---|---|---|
| **S Social diversity** | Kin and caregiver information networks; incidental meetings permitted | Persistent kin, friends, neighbors, and mentor ties, with directed trust, access, and contact frequency | No automatic knowledge or output bonus |
| **F Fear Logic** | Five needs, perceived threats and risks, ordinary planning, but no explicit fear-to-conviction persistence | Personal fear interpretation, values, willingness, commitment persistence, and source-tagged revisions | No automatic improvement to skill/physics |
| **B Collective belief** | Private beliefs, communication, and cooperation permitted, but no explicit group-level spiritual obligations | Shared claims through contact; assent, ritual, collective commitments, dissent and schism | No direct rainfall/plant/harvest bonus |
| **I Institutional feedback** | Institutions can have members, rules, resources, and operate under static governance | Same institution formation plus monitoring, dispute resolution, sanctions, revision and exit | No free budget, labor or legitimacy |

**Orthogonality:** An I=1,B=0 institution can monitor and revise technical rules without sacred collective beliefs. A B=1,I=0 group can share convictions without a formal institutional feedback loop. S=0 is kin-dominant, not no contact. F=0 does not remove hunger, fear response, or self-preservation; it removes the specified *interpretive commitment* mechanism.

### All 16 configurations

| Arm | S | F | B | I |
|---|---:|---:|---:|---:|
| S0F0B0I0 | 0 | 0 | 0 | 0 |
| S0F0B0I1 | 0 | 0 | 0 | 1 |
| S0F0B1I0 | 0 | 0 | 1 | 0 |
| S0F0B1I1 | 0 | 0 | 1 | 1 |
| S0F1B0I0 | 0 | 1 | 0 | 0 |
| S0F1B0I1 | 0 | 1 | 0 | 1 |
| S0F1B1I0 | 0 | 1 | 1 | 0 |
| S0F1B1I1 | 0 | 1 | 1 | 1 |
| S1F0B0I0 | 1 | 0 | 0 | 0 |
| S1F0B0I1 | 1 | 0 | 0 | 1 |
| S1F0B1I0 | 1 | 0 | 1 | 0 |
| S1F0B1I1 | 1 | 0 | 1 | 1 |
| S1F1B0I0 | 1 | 1 | 0 | 0 |
| S1F1B0I1 | 1 | 1 | 0 | 1 |
| S1F1B1I0 | 1 | 1 | 1 | 0 |
| S1F1B1I1 | 1 | 1 | 1 | 1 |

## 3. Shared physical and social starting world

- **Two worlds**, Solara and Vespara, orbiting one model **House** supplied by the **Wellspring**, with **ten Underworld layers**. World starting daylight: **70%** / **40%** respectively. Same Founder policy and decision rule across all arms; policy variation is a separate follow-up test.
- **Two settlements per world**, 24 creations per settlement = **96 mortal creations**, with **2 Founders** and **4 Castors** total.
- **Four habitat patches per world:** forest, grassland, wetland, ridge; material stocks held by one authoritative register; space/habitat/region grids reference that register.
- Per world: **30 Meadow Grazers, 30 Forest Browsers, 6 Ridge Hounds (pack), 4 Shadow Stalkers (ambush), 8 Carrion Birds, 6 Ground Scavengers, 8 Soil Fungus colonies**. All are actors with age, energy accounts, experience memories, species traits, and possible social learning. Total initial actors: **286**.
- Matched individual traits, household kinship, social-edge *potential* and per-actor initial knowledge by seed. Factor S changes which nonkin edges can operate—not the resource endowment or actor population.
- House initial reserve **300,000 EU**; Wellspring inflow **160 EU/day**; minimum sunlight **60 EU/day**, incremental emission fraction **0.30** of incoming energy, bounded by available House balance. These are **provisional experimental values**, not canon.
- Provisional transformation toll **10%** of accountable qualifying energy, distributed **20% world, 10% Underworld, 70% House**. Material state changes activate the toll; mere movement, observation, or ownership transfer does not. Actor, inventory, soil, body, water, and detritus materials all remain accounted for. No double-charged metabolism or crafting transitions.

### Schedule (days 1–720)

| Window | External event | Research role |
|---|---|---|
| 1–120 | Normal ecology, household formation, early teaching | Pre-shock baseline |
| 121–270 | Drought: same exogenous precipitation shock for every arm on a seed | Material scarcity and collective response |
| Day 155 | Two matched-source claims: evidence-supported water storage; false claim that ritual *alone* increases rainfall | Knowledge transmission, conformity, error correction |
| 271–540 | Recovery, weather restored | Institution persistence and learning |
| 541–720 | Long-term tracking, resource recovery, succession/replacement events if they arise endogenously | Persistence and distribution |

The false claim never changes physical rainfall directly. It may change actors' beliefs and therefore their choices. Sacred practice may still have social or organizational effects *if it produces actual interactions, labor, learning, or coordinated behavior*.

## 4. Unified event engine: one action, many consequences

A daily tick follows the blueprint contract:

1. Wellspring → House; House emits affordable minimum+inflow-linked sunlight; allocated light interacts with daylight and habitat absorption; internal energy transfers and Underworld layer queues logged.
2. Ecology and metabolism update through registered material-state transitions; mortality, digestion, growth and reproduction use physical stocks; changing material state charges the universal toll once.
3. Every actor receives local noisy observations (not world omniscience) and retrieves relevant memory, ties, values, and feasible current plans.
4. Individuals select a plan with physiological, safety, love/belonging, esteem/status, self-actualization, perceived risks, fear meaning (when F=1), obligations (when B=1), costs, and uncertainties.
5. Scheduler reserves inventory and energy, resolves simultaneous competition, executes atomic transactions, and rejects physically invalid changes.
6. Actual results become event records; actors only remember directly observed or socially transmitted information with source provenance.
7. Connected experience and practice develop skills, executive schemas, Nodes and potentially States. No routine Soul Network overload; extraordinary uncontrolled reality-energy manipulation only.
8. Groups and institutions form through sustained operational membership, explicit work, shared rules, budgets, governance, and accountability. I changes the *feedback* system, not whether a named group can exist.
9. Record both institution's **public claims** (RSW) and **actual logistics/outcomes** (PSW), distribution of costs/benefits, and disagreement. Finish with global audits and checkpoint.

**Account structure:** material composition is a single authoritative stock, separate from House/actor/environment/Underworld energy accounts. House-to-world sunlight is a debit from House; Wellspring energy is an explicit external boundary credit. The money-like symbol EU is a simulation unit, not necessarily an SI joule.

### Event record (required)

`event_id, day, world, patch, actor_id, action, goal_id, parent_event_ids, source_memory_ids, observed_claim_ids, resource_reservations, material_debits, material_credits, energy_debits, energy_credits, toll_destination_accounts, actual_result, observer_ids, transmitted_knowledge_ids, relationship_changes, skill_schema_node_changes, institution_id, institutional_claim_vs_outcome`

Events may have partial/multiple receivers. Neither animals nor mortals can learn from an event they never experienced or were told about.

## 5. Preregistered causal contrasts and metrics

### Co-primary outcomes

1. **Food-energy shortfall rate:** For living creations, sum daily missing metabolically accessible food energy divided by sum requirements for those same living creation-days. Report **death counts** and raw shortfall in parallel to avoid survivorship bias.
2. **Mortality fraction:** Deaths among the original 96 creations divided by 96, with age, household, world, and cause breakdown. Births tracked separately; replacements are not counted as original survivor outcomes.

### Primary estimates

For each matched seed and each factor, compare all arms with factor=1 to otherwise equivalent factor=0, averaging across the other factors (eight matched contrasts per factor per seed). The **30 seed-level average contrasts** are the independent units for uncertainty. The two worlds and four settlements are repeated measures, not 120 independent replicas.

Analyze four main effects × two co-primary outcomes with **Holm correction** (8 tests), plus 95% seed-block bootstrap intervals. Preregister three mechanistic interactions: **S×B, F×B, B×I**. Report effect size and uncertainty, not just significance; interaction and secondary analyses are labeled exploratory unless separately powered.

### Secondary measurements

| Family | Metrics and mechanism traces |
|---|---|
| Knowledge | Source-tagged exposure, claim accuracy, false belief adoption, belief correction latency, access inequality |
| Soul Network | Qualified experience-to-memory-to-skill chains, node formation, lost knowledge on death, intergenerational teaching |
| Relationships | Kin/friend/neighbor/mentor edges, trust asymmetry, relationship longevity, information flow over ties |
| Collective organization | Proposal → commitments → pooled resources → work → outcome, genuine dissent, ritual participation, social conformity |
| Institutions | Rule changes, monitor events, appeals, coercion, budgets, continuity, resource capture, group exit |
| RSW/CIV-OS | Declared sacred value, cognized vs operational model, RSW–PSW divergence, resource ownership, winners and losers |
| Ecology/energy | House reserve, sunlight absorption, Underworld queues, matter and energy audit, food-web persistence |
| Long-term agency | Completed plans/projects, abandoned plans, needs satisfaction, impact of sacrifices and commitments |

### Explicit mediation test

If B improves food security, trace whether it increased **actual shared work, better information, resource pooling or work allocation**. Disable coordination effects while retaining belief communication as a separate future ablation; if gains survive with no recorded physical or social pathway, reject the mechanism claim.

## 6. Negative controls and scientific failure conditions

- Turn belief formation on while preventing actual change in labor, resource allocation, technology, or sunlight; physical output must not change directly.
- Disabled nonkin edges cannot transmit a memory without direct observational contact.
- I=1 does not create free food, energy, materials, trust or automatically successful sanctions; I=0 groups can still have members and work.
- F must affect a decision through logged fear/interpretation/value/willingness; no silent scalar performance bonus.
- **Fatal:** energy not conserved within declared Wellspring boundaries; element/material batches duplicated; negative inventories; state transitions without a toll; two tolls for one transition; sunlight without House debit.
- **Invalid:** social norms without contact, skills without qualifying experience and memory, institutions with no real members/rules/resources, direct religion-yield bonuses, physically impossible hunting outcomes.
- Interpret refusal to update a false belief as a possible outcome, not automatically a defect. But a model that *forbids* evidence-based revision must be revised before claims about adaptation.

## 7. Quality gates and launch plan

1. Unit-test House emission, all ten Underworld layers, material state transitions, spoilage/cooking, births/deaths, and double-spend rollbacks.
2. Unit-test directed relationship transmission, conflicting testimony, source attribution, teacher death, actor memory revision, and Soul Network qualification.
3. Smoke test **10 days / one arm / one seed** (outside the 480-run preregistered study).
4. Diagnostic test **all 16 arms × 3 provisional seeds**, including mechanism traces. Do not evaluate hypothesis significance from diagnostics. **Freeze code, random stream construction, parameters, and predeclared thresholds afterward.**
5. Run **all 16 arms × 30 matched registered seeds**; retain compressed event logs + per-day state summaries, accounting audits, and version metadata.
6. Flag and explain any invalid run, audit complete seed blocks, report exclusions before analyzing outcomes; rerun changed code across the complete arm set, not just failed favorable cases.
7. Seed-block bootstrap, main effects and interactions, distributional welfare, RSW/PSW divergence, causal mediation traces; independent adversarial review.
8. Separate holdouts with climate timing reversed, missing mentors, resource capture, and fixed Founder policy. These extra experiments **do not count toward the 480 core runs**.

## 8. Interpretation guardrails

- A simulator's observed improvement is conditional on its code and parameters, not empirical validation of a real religious or social theory.
- A benefit may have unequal distribution; cost incidence is mandatory. Compare households, age cohorts, species, social access and institutional positions.
- Cultural persistence is not proof that a belief is true, socially beneficial, or freely accepted.
- Never infer an institution has agency separate from its actual members and rules.
- Holdout reversals and failure to find the hypothesized causal pathway count against the model rather than justifying automatic theory patches.
- Report expected versus observed outcomes. Pre-register falsifiers before running.

## 9. Artifacts

- `Founders_CIV_v016_Factorial_Study.json`: machine-readable rules, factors, baseline, metrics, analysis and assertions.
- `Founders_CIV_v016_Run_Manifest.csv`: exactly **480** run IDs, 16 arms × 30 seeds, plus exogenous/actor/internal seeds.
- `Founders_CIV_v016_Design_Validator.py`: verifies manifest pair matching and design integrity.
- The existing `Founders_CIV_v016_Integration_Blueprint.md` remains the source of canonical/provisional boundaries.
