"""Standalone v0.16 canonical accounting preflight. No ecology/RSW integration yet.

Tracks a single abstract conserved material (not chemistry) and accessible energy.
Move events only change accounts. Transformations must supply work from an energy
account, distribute the transition toll once, and route remainder to environmental heat.
Not a thermodynamic model of embodied energy; intended as an atomic contract test.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict
from typing import NamedTuple
import random

EPS=1e-9

@dataclass(frozen=True)
class Event:
    id: int
    kind: str
    material_moves: tuple[tuple[str,str,float], ...]
    energy_moves: tuple[tuple[str,str,float], ...]
    toll: float

class Ledger:
    def __init__(self):
        self.material={'forest_live':100., 'forest_dead':0., 'lumber':0., 'warehouse':0., 'soil':0.}
        self.energy={'actor':300.,'world':0.,'underworld':0.,'house':500.,'heat':0.}
        self.external=0.
        self.events=[]
        self.start_mass=sum(self.material.values())
        self.start_energy=sum(self.energy.values())
        self._id=0

    def apply(self,kind:str,material_moves=(),energy_moves=(),toll:float=0., external_inflow=0.):
        """Apply a complete atomic, balanced change; failures leave state unchanged."""
        if kind not in ('move','transform','wellspring'):raise ValueError('unknown event kind')
        if external_inflow<0:raise ValueError('negative inflow')
        if kind=='move' and toll!=0:raise ValueError('movement cannot incur toll')
        if kind!='transform' and toll!=0:raise ValueError('nontransform cannot incur toll')
        if kind=='transform' and not material_moves:raise ValueError('transformation requires material state change')
        m=dict(self.material);e=dict(self.energy)
        for source,target,amount in material_moves:
            if source not in m or target not in m or source==target or amount<=0:raise ValueError('invalid material transfer')
            m[source]-=amount;m[target]+=amount
        for source,target,amount in energy_moves:
            if source not in e or target not in e or source==target or amount<=0:raise ValueError('invalid energy transfer')
            e[source]-=amount;e[target]+=amount
        if kind=='wellspring':
            if material_moves or energy_moves or external_inflow<=0:raise ValueError('invalid external inflow')
            e['house']+=external_inflow
        else:
            if external_inflow!=0:raise ValueError('only Wellspring can inject external energy')
        if min(m.values())<-EPS or min(e.values())<-EPS:raise ValueError('insufficient balance')
        if abs(sum(m.values())-self.start_mass)>EPS:raise AssertionError('mass conservation')
        if abs(sum(e.values())-(self.start_energy+self.external+external_inflow))>EPS:
            raise AssertionError('energy conservation')
        if kind=='transform':
            # Toll is not an additional debit; it is a tagged part of work-energy routing.
            allocations=sum(amount for source,target,amount in energy_moves if target in ('world','house','underworld'))
            if abs(allocations-toll)>EPS:raise ValueError('toll allocations do not match declared toll')
        self.material=m;self.energy=e;self.external+=external_inflow
        self._id+=1
        event=Event(self._id,kind,tuple(material_moves),tuple(energy_moves),toll)
        self.events.append(event)
        return event

    def transform(self,source:str,target:str,mass:float,work:float,toll_rate=.10):
        toll=work*toll_rate
        moves=[('actor','heat',work-toll),('actor','world',toll*.2),
               ('actor','underworld',toll*.1),('actor','house',toll*.7)]
        return self.apply('transform',[(source,target,mass)],moves,toll=toll)

    def audit(self):
        return {'material_error':sum(self.material.values())-self.start_mass,
                'energy_error':sum(self.energy.values())-(self.start_energy+self.external),
                'events':len(self.events),'external':self.external}


def run_stress(seed=1729,attempts=5000):
    rng=random.Random(seed);l=Ledger();accepted=0;rejected=0
    for i in range(attempts):
        kind=rng.choice(('move','transform','transform','wellspring'))
        try:
            if kind=='wellspring':l.apply('wellspring',external_inflow=.015)
            elif kind=='move':
                source,target=rng.choice((('lumber','warehouse'),('warehouse','lumber')))
                l.apply('move',[(source,target,.08)],())
            else:
                source,target=rng.choice((('forest_live','forest_dead'),('forest_dead','lumber'),('lumber','soil')))
                l.transform(source,target,.06,work=.03)
            accepted+=1
        except ValueError:rejected+=1
    check=l.audit()
    assert abs(check['material_error'])<EPS and abs(check['energy_error'])<EPS
    return {'seed':seed,'attempts':attempts,'accepted':accepted,'rejected':rejected,**check}

if __name__=='__main__':print(run_stress())
