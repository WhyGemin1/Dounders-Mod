# Pre-integration Integrity Gate

| Gate | Status | Evidence | Next action |
|---|---|---|---|
| Original v0.12 output preserved after performance refactor | PASS | 60-day golden test | Keep regression fixture |
| Original v0.14 output preserved after performance refactor | PASS | 120-day golden test | Keep regression fixture |
| Species experiments isolated across modes | PASS | Instance-scoped species table test | Preserve injection contract |
| Determinism across hash-seed environments | PASS | Sorted animal-culture iteration; cross-process checks | Add routine CI checks |
| Correct destination scored in migration learning | PASS | Targeted migration-feedback test | Retain fixed default |
| Existing ecology accounting | PASS WITH LIMITATIONS | Audited 120-day standalone pilots | Replace coarse physics with registered transactions |
| Atomic ledger can reject duplicate/overdrawn changes | PASS | 15,000 attempted transactions, conservation checks | Integrate as source of truth |
| Social learning separates source/acceptance/practice | PASS IN STANDALONE PILOT | Isolated/kin/diverse study | Connect to actual relationships and Soul Networks |
| v0.14 conservation and physical RSW-PSW work coupling | BLOCKED | Known toy stocks and trust-driven work bonus | Remove shortcuts before integration |
| Canonical toll triggered only by state transformations in actual ecology engine | BLOCKED | Legacy default `spend(state=True)` | Explicit transition event contract |
| Emergent institutions with members, rules and resources | BLOCKED | Legacy action-count and norm thresholds | Implement institutional entities |
| 4-factor × 30-seed, 720-day integrated study | NOT STARTED | Design and manifest exist only | Run integrated smoke tests first |

**Interpretation:** mechanical preflight ready; **full integrated integrity not yet demonstrated**.
