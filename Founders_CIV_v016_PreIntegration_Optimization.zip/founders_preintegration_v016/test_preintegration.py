"""Pre-integration correctness tests; run python -m unittest -v test_preintegration."""
from __future__ import annotations
import hashlib,json,unittest
from pathlib import Path
import founders_v012 as core
import founders_v013_species as species
import founders_v014_rsw_experiment as rsw
from social_preflight import SocialPilot
from transaction_preflight import Ledger,run_stress

HERE=Path(__file__).resolve().parent

class AccountingTests(unittest.TestCase):
    def test_atomic_rollback(self):
        l=Ledger();old=l.audit().copy(); m=l.material.copy();e=l.energy.copy()
        with self.assertRaises(ValueError):l.apply('move', [('forest_live','warehouse',101)])
        self.assertEqual(old,l.audit());self.assertEqual(m,l.material);self.assertEqual(e,l.energy)

    def test_no_toll_for_movement(self):
        l=Ledger();a=l.apply('move',[('forest_live','warehouse',1.5)])
        self.assertEqual(a.toll,0)
        self.assertEqual(l.audit()['energy_error'],0)
        with self.assertRaises(ValueError):l.apply('move',[('forest_live','warehouse',1)],toll=.01)

    def test_toll_exact_once(self):
        l=Ledger();before=l.energy.copy()
        a=l.transform('forest_live','forest_dead',1.0,work=.3)
        self.assertAlmostEqual(a.toll,.03)
        self.assertAlmostEqual(l.energy['actor'],before['actor']-.3)
        self.assertAlmostEqual(l.energy['house'],before['house']+.03*.7)
        self.assertAlmostEqual(sum(l.material.values()),l.start_mass)

    def test_wellspring_accounted(self):
        l=Ledger();l.apply('wellspring',external_inflow=25)
        self.assertAlmostEqual(l.energy['house'],525)
        self.assertLess(abs(l.audit()['energy_error']),1e-9)

    def test_ledger_stress(self):
        a=run_stress(12,1000)
        self.assertLess(abs(a['energy_error']),1e-8)
        self.assertLess(abs(a['material_error']),1e-8)

    def test_full_ecology_audit(self):
        s=species.Sim('combined',12011,35,False)
        result=s.run()
        self.assertLess(result['energy_error_max'],1e-5)
        self.assertLess(result['mass_error_max'],1e-5)

    def test_audit_catches_illegal_energy(self):
        s=core.Simulation(12011,1,False)
        s.house+=2
        with self.assertRaises(AssertionError):s.audit(1)

    def test_audit_catches_illegal_matter(self):
        s=core.Simulation(12011,1,False)
        s.worlds[0].patches['forest'].env['C']+=1
        with self.assertRaises(AssertionError):s.audit(1)

class DeterminismTests(unittest.TestCase):
    def test_core_golden(self):
        expected=json.loads((HERE/'baseline_base.json').read_text())['result']
        actual=core.Simulation(12011,60,False).run()
        self.assertEqual(expected,actual)

    def test_rsw_golden(self):
        expected=json.loads((HERE/'baseline_rsw.json').read_text())['result']
        actual=rsw.World('C',12011,120,False).run()
        self.assertEqual(expected,actual)

    def test_species_same_seed_reproducible(self):
        a=species.Sim('combined',12011,40,False).run()
        b=species.Sim('combined',12011,40,False).run()
        self.assertEqual(a,b)

    def test_species_profiles_are_per_run(self):
        a=species.Sim('baseline',12011,2,False)
        b=species.Sim('combined',12011,2,False)
        self.assertEqual(a.species['pack_hound']['capacity'],16)
        self.assertEqual(b.species['pack_hound']['capacity'],38)
        self.assertEqual(a.species['pack_hound']['capacity'],16)
        self.assertNotIn('pack_hound',core.SPECIES)
        self.assertIsNot(a.species,b.species)

    def test_spatial_index_updates_on_death(self):
        s=species.Sim('combined',12011,1,False)
        w=s.worlds[0];a=next(a for a in w.agents if a.species=='grass_grazer')
        self.assertIn(a,w.present(a.patch,a.species))
        s.die(w,a,'test')
        self.assertNotIn(a,w.present(a.patch,a.species))

    def test_correct_migration_feedback(self):
        s=species.Sim('combined',12011,1,False,fix_migration=True);w=s.worlds[0]
        a=next(a for a in w.agents if a.species=='grass_grazer' and a.patch=='grassland')
        for p in w.patches.values():p.stock['plant'][0]=0.1
        w.patches['forest'].stock['plant'][0]=100.
        a.route_value={p:0. for p in core.PATCHES}
        self.assertTrue(s.migration(w,a,1))
        self.assertEqual(a.patch,'forest')
        self.assertAlmostEqual(a.route_value['forest'],.1)

class SocialTests(unittest.TestCase):
    def test_isolated_no_exposure_no_training(self):
        p=SocialPilot('isolated',1);r=p.run(50)
        self.assertEqual(r['messages'],0)
        self.assertEqual(r['trained_actors'],0)
        self.assertEqual(r['correct_claim_adopters'],1)

    def test_knowledge_does_not_grant_skill(self):
        p=SocialPilot('family',2);p.run(3)
        self.assertTrue(all(a.skill['safe_route']==0 for a in p.people if not a.practiced['safe_route']))

    def test_knowledge_source_is_recorded(self):
        p=SocialPilot('diverse',1);p.run(30)
        self.assertTrue(len(p.messages)>0)
        for day,sender,recipient,claim in p.messages:
            self.assertIn((day,sender,claim),p.people[recipient].exposures)

if __name__=='__main__':unittest.main(verbosity=2)
