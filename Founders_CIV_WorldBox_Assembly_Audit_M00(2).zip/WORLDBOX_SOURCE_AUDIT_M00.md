# Founders–CIV × WorldBox — M00 source-level compatibility audit

Status: **static evidence collected; no live WorldBox mod has been compiled or tested in this audit**.

## Inputs and reproducibility

- User-supplied `Assembly-CSharp.dll`: SHA-256 `51d275f0168be2f6ca26341ab292406714e694e0270eafcb25b999d5df6dd69f`.
- `db.tables.dll`: SHA-256 `0d14cd76e33c1f781b33b70de23b42dffa2018baba3a846f00144d97e7167500`.
- Extracted ECMA-335 metadata using local, original Python `inspect_metadata.py` (read-only). Main assembly: **2,906 TypeDef records, 21,566 MethodDef records, 15,668 Field records**. These are raw metadata counts, not game features or tested interception points.
- `fullya99/worldbox-mcp` `docs/game-api-notes.md` identifies this exact main assembly SHA as **WorldBox 0.51.2** (Unity 2022.3.60f1 Mono). This is a strong static match; runtime version and mod behavior must still be checked with `worldbox_health` on the user's machine.
- Reference integration code: `WhyGemin1/worldbox-mcp`, a public fork of `fullya99/worldbox-mcp`; Python API ⇄ authenticated loopback HTTP ⇄ BepInEx C# plugin ⇄ reflected game types on Unity main thread.
- Reference Core151: `Founders_CIV_Core151_Physiology_PredatorPrey_Experimental.zip`; `src/unified_foraging_151.py`, `src/core_physiology_v2.py`, `world023024/founders_civ/experimental/world_trees.py`, `world023024/founders_civ/core/ledger.py`.

## Directly observed WorldBox surface (metadata only)

| WorldBox type | Members in supplied binary | Proposed integration boundary | Verification still needed |
|---|---|---|---|
| `Actor` | `addNutritionFromEating`, `updateNutritionDecay`, `spendNutritionOnBirth`, `getNutrition`, `needsFood`, `getStamina`, `registerDecisions`, `nextJobActor`, `checkDeath`, `birthEvent`, `consumeFoodResource` | Managed-actor needs and outcomes | Method signatures, call sequence, interception safety |
| `ActorData` | `nutrition`, `stamina`, `generation`, `parent_id_1`, `parent_id_2`, `saved_traits`, `food_consumed` | Native ID ↔ core ID, species traits, phenotype mirrors | Serialized format and precise ID semantics |
| `ActorManager` | `spawnNewUnit`, `createNewUnit`, `createBabyActorFromData`, `loadFromSave`, `destroyObject` | Birth/death enrollment, save/load resynchronization | Distinguish native spawns, load replay, actor reconstruction |
| `ActorAsset` | `split_ai_update`, `decision_ids`, `nutrition_max`, `default_subspecies_traits`, `addDecision` | Species templates and AI task registration | When WorldBox refreshes native decisions |
| `BehCheckNeeds` / `BehFindMeatSource` | `execute`; meat source targeting helpers | Candidate AI handoff | Whether they can safely be suppressed per managed actor |
| `BehAnimalBreedingTime`, `BehSexualReproductionTry`, `BehCheckReproductionBasics` | `execute` | Reproduction authority | Native birth side effects, gestation and cooldown handling |
| `ActorTraitLibrary`, `SubspeciesActorBirthTraits` | Birth and inheritance pathways present | Core151 heritable trait synchronization | Mapping of native traits to Core151 eight numeric dimensions |
| `WorldBehaviourActions` / `WorldBehaviourActionBiomes` | `tryGrowVegetation`, `growVegetationAt`, `update`, `trySpreadBiomeAround` | Habitat production, World Tree ecological feedback | How plant growth affects tiles, food and native population |
| `WorldLawLibrary` / `WorldLaws` | Hunger, animal spawning, animal babies, plant spread toggles | Global safety switches for test maps | Settings are global, not proven per-species; avoid unintended disabling |
| `MapBox` | Static `instance`, `updateSimulation`, `updateActors`, `timer_nutrition_decay`, `on_world_loaded` | Visible selected-World runtime | Singleton means multiple simultaneous rendered maps are NOT demonstrated |
| `SaveManager` | `saveWorldToDirectory`, `saveMapData`, `loadWorld`, `loadActors` | Paired save checkpoint | Transaction order and crash atomicity |
| `CityManager`, `KingdomManager`, `CultureManager` | Settlement/kingdom/culture creation and update methods | Later Creation societies | Their native autonomy and Core founder governance must not conflict |
| `GodPower`, `PowerLibrary` | Terrain and spawning actions; existing UI power system | Founder interventions mediated by Book | Costs, permissions and rollback for a failed game action |

**Do not infer behavior from names alone.** These are candidates for runtime probes and CIL inspection, NOT verified hooks or proof of a corresponding biological model.

## What WorldBox already provides that we should reuse

- 2D terrain, vegetation visuals, city and culture simulation, animation, navigation, maps and save/load mechanics.
- Individual native units with nutrition and stamina state, traits, lineage and multiple reproduction-strategy behaviors.
- Live world observation and command invocation through the existing WorldBox MCP bridge.

## What Founders–CIV should authoritatively own

- Persistent `world_id`, `tree_id`, `founder_id`, `creation_id`, `spirit_id`, and `civ_actor_id`.
- One Book for energy and mass transfers; physical World creation and upkeep; provenance/event IDs.
- Physiology that includes gut, fuel, reserves, tissue catabolism, digestion, maternal funding and individual traits.
- Ecological decision state for managed species, grounded energy costs, offspring and deaths; Founder research, learning, stewardship and interworld exchange.
- One monotonic simulation clock. WorldBox ticks and time-scale UI may advance presentation, but must not mint core time, food or energy.

## Critical architectural hazard: two authorities

WorldBox has independent nutritional and reproductive code (`Actor.updateNutritionDecay`, `spendNutritionOnBirth`, `ActorManager.createBabyActorFromData`), while Core151 has its own ledger-backed digestion, death, and births. Applying both creates duplicate consumption or offspring. Managed actors must use **one exclusive authority** for each state field and event:

1. **Observer mode**: WorldBox controls behavior; adapter only reads and compares.
2. **Shadow mode**: Core151 calculates decisions but changes no WorldBox resource state. Compare event traces.
3. **Managed mode, per species**: Core151 approves authoritative feeding, births, deaths and energy/material transitions; WorldBox executes accepted visual consequences once. Native automatic biological changes for those enrolled actors must be suppressed or reconciled with demonstrated correctness.

Never switch all fauna at once. Keep unrelated WorldBox actors fully vanilla until the paired event, save/load and crash tests pass.

## Discrete implementation risks

- **Unity main thread**: The existing bridge documents marshaling reflected WorldBox operations to the main thread. Never modify Unity/game objects from an HTTP handler thread.
- **Reference stability**: `ActorManager.loadFromSave` may reconstruct actors; use persistent native actor identifiers plus a per-world mapping, not pointers to Unity objects.
- **Save consistency**: Two independent save files can diverge after a crash. Journal event IDs and synchronized snapshot epochs; don't treat separate successful saves as atomic without testing.
- **WorldBox version**: Current assembly matches one documented 0.51.2 build, but future updates require new fingerprints and a new compatibility audit.
- **World multiplicity**: A single `MapBox.instance` suggests one active rendered map per process. Use a headless WorldTreeRegistry for other Worlds rather than claiming multiple WorldBox maps can coexist natively.
- **Intellectual property**: Do not publish the user's downloaded game DLLs, PDBs, decompiled source, Unity assets or full metadata dumps. Share original integration code, compatibility observations and link to public tools instead.

## Next actual executable research tasks

1. Run `worldbox_health` and `worldbox_capabilities`; compare returned SHA and game build with the supplied binary.
2. Add **read-only** `actor_id`, `world_id`, `x/y`, `nutrition`, `stamina`, `generation`, `parent_ids` query (if supported by safe reflection), with explicit nulls for unknown fields.
3. Run 20 load/save/actor-survival smoke trials in a disposable game save; require stable identity maps.
4. Record a one-day native feeding trace with nutrition before/after, and identify exact source of resource changes.
5. Implement shadow-mode Core151 `ForagingState151` calculation for a chosen native animal; compare native vs core hunger state without game mutation.
6. Test a single **Book-authorized** consume event with durable event ID and a forced rejection path; pass only when duplicate replay is harmless and neither game nor Book double credits.
7. Repeat for birth and death on one controlled rabbit/fox pair, then expand to the World Tree.

## Public supporting references

- https://github.com/WhyGemin1/worldbox-mcp
- https://github.com/fullya99/worldbox-mcp/blob/main/docs/game-api-notes.md
- https://github.com/fullya99/worldbox-mcp/blob/main/docs/architecture.md
- https://github.com/fullya99/worldbox-mcp/blob/main/docs/development.md
- https://github.com/WorldBoxOpenMods/ModLoader
