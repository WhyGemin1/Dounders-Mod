# WorldBox × Founders–CIV Assembly Audit M00

- `WORLDBOX_SOURCE_AUDIT_M00.md`: Verified class names, compatibility fingerprint, integration opportunities, constraints, tests and public references.
- `FOUNDER_SPACE_ARCHITECTURE_M00.md`: How the First House, 100 Founders, World Trees, Spirits, Creations and Realms should interact with WorldBox.
- `inspect_metadata.py`: Original, read-only .NET metadata-name scanner, requires only Python standard library; does **not** run Unity or the game.
- The tool outputs raw `.types.json` locally for inspection, but these raw extracted tables **are not included** in this shareable audit package and must not be committed to public GitHub.

**Evidence categories:** WorldBox binary metadata and fork documentation are verified statically; proposed hooks and WorldBox interactions require on-device runtime verification. This package does not include proprietary WorldBox binaries or assets.
