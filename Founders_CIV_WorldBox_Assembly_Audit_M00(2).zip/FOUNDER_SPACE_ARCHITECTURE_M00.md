# Founders–CIV — Founders' operational space and World Tree runtime

Status: **design and acceptance contract; not an implemented WorldBox extension**.

## Preserve the First House rather than making it an ordinary WorldBox civilization

**The First House** is a top-level, separately persisted Founders–CIV domain. It holds 100 individual Founders, relationships, shared research, the Research Accord, checkpoints, the central Book, and the registry of Worlds. A Founder can exist and make decisions even when a WorldBox map isn't loaded.

WorldBox is a **local World view / execution surface** for exactly one selected WorldTree at a time until multiple-map support is demonstrated. This arrangement prevents the House from being erased during a WorldBox map regenerate/load, and avoids misrepresenting WorldBox kingdoms as Founder societies.

## Proposed state domains

| Domain | Owner | Scope |
|---|---|---|
| House, 100 Founders, knowledge, relationships and Accord | Founders–CIV | global across Worlds |
| WorldTreeRegistry | Founders–CIV | `world_id -> tree_id, founder_ids, state, checkpoint_epoch` |
| Book | Founders–CIV | account keys include `world_id`; cross-world transfer debits and credits |
| Managed animals and Creations | Founders–CIV | persistent `civ_actor_id`; one-to-one adapter mapping to visible WorldBox actor |
| Native WorldBox creatures not enrolled | WorldBox | vanilla behavior; excluded from Book-coupled ecological guarantees |
| Selected World map, animations, terrain, cities | WorldBox | visible projection and native execution |
| Spirits | Founders–CIV | capability contracts, resource budgets and World affiliation, not unrestricted world edits |
| Realm graph | Founders–CIV | approved links between Worlds, each with transfer rules |

## Founder participation modes

1. **Observing**: Founder receives a sampled World ecology report with information limits; observation updates knowledge, not Book resources.
2. **Researching**: Founder proposes hypotheses/experiments, pays real equipment/material costs if needed, and updates knowledge based on outcomes.
3. **Stewardship**: Founder proposes an intervention (plant, redirect water, introduce species, move resources, build habitat), checks conservation and World permissions, and then sends an approved operation through the bridge.
4. **Delegating**: Founder can instruct Spirits or Creations, who maintain their own agency and material constraints.
5. **Connecting Worlds**: Founder proposes a Realm link; moving actors or energy between Worlds must preserve identities and Book conservation.

**UI concept**: Founders tab alongside WorldBox's god powers, displaying Founder identities, House reports, owned World Trees, and proposals awaiting settlement. No separate Founder 2D entities are necessary for M00–M03. Optional visual avatars can be added after authority and persistence tests.

## M00→M08 engineering gates

| Milestone | Minimum passing test |
|---|---|
| M00: static compatibility | Frozen assembly hash matches documented bridge; C# plugin builds and loads on user's PC |
| M01: actor identity | 20 world save/load cycles preserve mapping, parents, generation and traits |
| M02: shared feeding | 100 duplicated/replayed feed event attempts settle exactly once, paired mass+energy Book audit passes |
| M03: living World Tree | Habitat survives 30/180/360-day tests; G2/G3 prey; predator nutritional and demographic outcomes measured, never falsely declared stable |
| M04: Founder steward | One autonomous Founder completes an observe→research→funded intervention→result loop |
| M05: two Worlds | World A and B both advance without rendering; switching maps doesn't duplicate or discard populations |
| M06: Spirits/Creations | Spirit action respects resource/ability constraints; Creation carries persistent life history and independent decision process |
| M07: first Realm | Accounted cross-world shipment, actor travel, saved link graph and no duplication after reload |
| M08: wider alpha | 30 matched seeds × 30, 180, 360, 720, 1080 days; regression, conservation and performance budgets |

## Initial WorldBox-to-Core event pipeline

`WorldBox proposes event -> adapter resolves world/actor IDs -> Core151 validates physics + Book -> journal event ID -> confirmed WorldBox visual action -> ack + reconcile -> periodic consistent checkpoint`

All operations require idempotency. A rejected or timed-out Book transaction must NOT create a free visible food transfer. A simulated accepted event with a failed game-side animation must be recoverable without applying the Book transaction twice.

## Design alternatives to validate

- A "Founder House" virtual panel in the game versus a separate House map loaded through the same bridge.
- Native WorldBox city AI operating autonomously as Creation societies versus selected cities under additional Core social policy.
- A WorldBox tile representing a Word Tree portal versus a menu-based registry and switching between saved maps.
- Per-World separate Book subaccounts under one ledger versus per-World subledgers reconciled to a common parent (first is simpler for M00).

For the first slice, favor **House external + WorldBox selected World**; test one funded Founder planting action before investing in avatar rendering or Realm navigation.
