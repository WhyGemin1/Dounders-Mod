"""Read only ECMA-335 TypeDef/MethodDef/Field names from local managed binaries.
No game code extracted or executed. Uses Python stdlib. For local research only.
"""
import struct, sys, json
from pathlib import Path

def u16(d,p): return struct.unpack_from('<H',d,p)[0]
def u32(d,p): return struct.unpack_from('<I',d,p)[0]
def u64(d,p): return struct.unpack_from('<Q',d,p)[0]
def analyze(filename):
 d=Path(filename).read_bytes()
 pe=u32(d,0x3c); assert d[pe:pe+4]==b'PE\0\0'
 nsec=u16(d,pe+6); ops=u16(d,pe+20); opt=pe+24; magic=u16(d,opt)
 dd=opt+(96 if magic==0x10b else 112); cli_rva=u32(d,dd+14*8)
 sh=opt+ops; sections=[]
 for i in range(nsec):
  p=sh+40*i; name=d[p:p+8].rstrip(b'\0').decode('ascii','replace'); vs=u32(d,p+8); va=u32(d,p+12); raw=u32(d,p+16); off=u32(d,p+20); sections.append((name,va,max(vs,raw),off))
 def rva(v):
  for name,va,s,off in sections:
   if va<=v<va+s: return off+v-va
  raise ValueError(('no rva',hex(v)))
 cli=rva(cli_rva); meta=rva(u32(d,cli+8)); assert d[meta:meta+4]==b'BSJB'
 verlen=u32(d,meta+12); ver=d[meta+16:meta+16+verlen].rstrip(b'\0').decode('utf8','replace'); p=(meta+16+verlen+3)&~3; p+=2; stream_n=u16(d,p); p+=2
 streams={}
 for i in range(stream_n):
  ofs=u32(d,p); size=u32(d,p+4); q=p+8; e=d.index(b'\0',q); name=d[q:e].decode('ascii','replace'); streams[name]=(meta+ofs,size); p=(e+4)&~3
 st=streams.get('#~',streams.get('#-')); assert st,streams
 strings=streams['#Strings'][0]; blob=streams['#Blob'][0]; guids=streams['#GUID'][0]; tabs=st[0]
 heap_sz=d[tabs+6]; valid=u64(d,tabs+8); p=tabs+24; counts={}
 for i in range(64):
  if (valid>>i)&1: counts[i]=u32(d,p); p+=4
 def heapwidth(b):return 4 if heap_sz&b else 2
 S=heapwidth(1); B=heapwidth(4); G=heapwidth(2)
 def ix(n):return 4 if counts.get(n,0)>=65536 else 2
 def coded(bits,t):return 4 if max(counts.get(n,0) for n in t)>=(1<<(16-bits)) else 2
 def strheap(pos):
  if pos==0:return ''
  q=strings+pos; e=d.index(b'\0',q); return d[q:e].decode('utf8','replace')
 def num(p,w):return u16(d,p) if w==2 else u32(d,p)
 # 0 module, 1 TypeRef, 2 TypeDef, 3 FieldPtr, 4 Field, 5 MethodPtr, 6 MethodDef
 fields=[]; methods=[]; types=[]
 for t in range(7):
  if t not in counts:continue
  if t==0: size=2+S+G*3
  if t==1:size=coded(2,[0,26,35,1])+2*S
  if t==2:size=4+2*S+coded(2,[2,1,27])+ix(4)+ix(6)
  if t==3:size=ix(4)
  if t==4:size=2+S+B
  if t==5:size=ix(6)
  if t==6:size=4+2+2+S+B+ix(8)
  for i in range(counts[t]):
   q=p+i*size
   if t==2:
    flags=u32(d,q); nameidx=num(q+4,S); nsidx=num(q+4+S,S); z=q+4+2*S+coded(2,[2,1,27]); first_field=num(z,ix(4)); first_method=num(z+ix(4),ix(6))
    types.append(dict(name=strheap(nameidx),ns=strheap(nsidx),flags=flags,fields_start=first_field,methods_start=first_method,token=0x02000000+i+1))
   if t==4:fields.append(dict(name=strheap(num(q+2,S)),token=0x04000000+i+1,flags=u16(d,q)))
   if t==6:methods.append(dict(name=strheap(num(q+8,S)),token=0x06000000+i+1,flags=u16(d,q+6),rva=u32(d,q)))
  p+=size*counts[t]
 for i,t in enumerate(types):
  endf=(types[i+1]['fields_start'] if i+1<len(types) else len(fields)+1)-1; endm=(types[i+1]['methods_start'] if i+1<len(types) else len(methods)+1)-1
  t['fields']=[x['name'] for x in fields[t['fields_start']-1:endf]]; t['methods']=[x['name'] for x in methods[t['methods_start']-1:endm]]; t.pop('fields_start');t.pop('methods_start')
 return dict(file=Path(filename).name,version=ver,type_count=len(types),method_count=len(methods),field_count=len(fields),types=types)
if __name__=='__main__':
 for x in sys.argv[1:]:
  r=analyze(x); print(f"{r['file']}: {r['type_count']} types {r['method_count']} methods {r['field_count']} fields; {r['version']}")
  out=Path('/mnt/data/WorldBox_Founders_Integration_Audit')/(Path(x).name+'.types.json');out.write_text(json.dumps(r,ensure_ascii=False,indent=2));print(out)
