# Founders–CIV × WorldBox: Research-Backed Development Roadmap

**Prepared 2026-11-13.** Research catalog based on publicly accessible sources checked during this conversation. This is a **plan**, not a claim that the WorldBox mod or integrations already exist.

## Project mission

Develop a persistent society/ecology simulation where 100 autonomous Founders research and create living World Trees, use actual physical budgets to maintain Worlds, create Spirits and mortal Creations, and connect Worlds as Realms. WorldBox is the local visible simulation host; Founders–CIV Core151 (experimental) remains the authoritative Python system for actor identity, biology, knowledge, Book ledger and global clock.

## Present state and known limitations

- Core151: headless engine and tests exist; measured reduction in false physiological deaths, but predator survival fails in longer standard-reference runs.
- 13 bridge species and native World Tree systems have substantial source code. System-wide ecological calibration and interaction effects remain unresolved.
- Minecraft Cycle M01 was a research/adapter investigation; it is **not** a WorldBox mod.
- A WorldBox integration is **not yet compiled, installed, or verified** for this project. Public modding examples are version-specific; even successful observation/spawn does not prove that vanilla feeding, breeding, death and drops can be overridden.

## Architecture and non-negotiable contracts

- `FounderCore`: authoritative Founder knowledge, identity, social relationships and project intentions.
- `WorldRegistry`: each `world_id` maps to ecology state, Book accounts, production and structural maintenance, owner/stewards, connected realms.
- `Book`: a single authority for all conserved material/chemical energy/water transfers; actions cannot credit free energy.
- `ActorRuntime`: metabolism, age, traits, genetics, digestion, recovery, movement intentions, breeding and mortality.
- `WorldBoxAdapter`: C# in-game connector and Python bridge; renders and executes agreed physical intentions, with no second authoritative metabolism or birth generator.
- `EventProtocol`: idempotency key `event_id`, world ID, actor ID, expected version, authoritative settlement receipt, retry/reconcile; records movement, eat, attack, death, birth, drops, Spirit and Founder actions exactly once.
- `GlobalClock`: time is measurement, not an energy currency. A WorldBox game-speed multiplier must not silently advance a World twice. Distant Worlds advance via the shared headless clock.
- `RealmGraph`: verified link/portal identifiers and explicit transfer transactions; access permissions and rollback.

## Build milestones

### M00: Freeze and audit

**Deliverable:** Core151, Core145 G2 reference, WorldBox version, mod loader, source manifests, repository and reversible feature flags.

**Acceptance:** Core source fingerprint; mod builds & loads; no vanilla behavior changed; no copied game assets.

**Dependencies:** WorldBox installation; pinned versions; Python/C# toolchains.

**Decision rule:** Go only if minimal mod loads and clean save reload works.

### M01: One persistent actor

**Deliverable:** Bidirectional ActorId ↔ WorldBox Actor GUID mapping; snapshot/enroll/detach; unit/owner registry; safe death and despawn handling.

**Acceptance:** Same actor ID, traits and physiological balance after 10 save/reloads; 0 duplicate actors; reversible unload.

**Dependencies:** M00, WorldBox actor APIs.

**Decision rule:** Go only if identity/persistence survives save+load.

### M02: Physical-event authority

**Deliverable:** Capture movement, eating, hunts, damage, birth/death, drops. Introduce one event-ID acknowledgement protocol and one Book settlement.

**Acceptance:** 100% audited covered events exactly once; no vanilla double-spawn/birth/drop; invalid event rejected and game reconciled.

**Dependencies:** M01, event interception research.

**Decision rule:** If native rules cannot be gated, host acts as viewer and authoritative ecology remains external.

### M03: One living habitat

**Deliverable:** One Founder; World Tree; vegetation, water/soil, 2 prey species, 1 predator, carrion, physiology and trait inheritance.

**Acceptance:** G2/G3 descendants in suitable reference conditions; explicit physiological causes of death; positive/negative mass-energy conservation audits; 30/180/360 day headless runs.

**Dependencies:** M02, Core151, DEB/EltonTraits/GloBI.

**Decision rule:** No success by preset births, reserve gifts or immunity.

### M04: Full species ecology

**Deliverable:** Add remaining 10 bridge species and native residents; calibrated feeding/growth/rest; species-specific refuge/predation; resource recirculation.

**Acceptance:** Per-species feeding/maturity/reproduction tests; multi-seed 30/180/360/720/1080 horizon comparisons; no duplicate digestions.

**Dependencies:** M03, empirical life histories.

**Decision rule:** Keep failed species flagged; never equate Book balance with ecological viability.

### M05: Founder stewardship

**Deliverable:** Connect 100 Founder registry to research, observation, decisions, physical funding of World Tree construction/ecology and real interventions.

**Acceptance:** One independent Founder preserves or alters World state via Book transfers; refusal on insufficient resources; deterministic decision trace.

**Dependencies:** M02-M04, Founder social engine.

**Decision rule:** Founder decisions must not directly edit energy or populations.

### M06: Two Worlds / state scheduler

**Deliverable:** World registry and unique accounts; global clock; background World stepping; visible WorldBox view independent of persistent World simulation.

**Acceptance:** Two independent Worlds advance for 360 days while one is viewed; save/reload exact replay; no double world tick; conserved interworld transfers.

**Dependencies:** M05 and core time/Book.

**Decision rule:** Do not assume WorldBox can run multiple maps simultaneously.

### M07: Creations and Spirits

**Deliverable:** Introduce durable Creation identity, inheritance and society roles; typed Spirit powers and costs; dependency on world resources and knowledge.

**Acceptance:** One Creation population develops without forced outcomes; Spirit action validated once, debit/credit/heat accounted; safe save/load and refusal.

**Dependencies:** M06 and established canon/specification.

**Decision rule:** Specify scope of Spirit exceptions before coding; do not create free resources.

### M08: First Realm

**Deliverable:** Connect Worlds through explicit graph edges: travel, trade, permissions, Founder agreements, governance, conflict and knowledge exchange.

**Acceptance:** Two Worlds exchange a resource and an actor with consistent ownership/identity; edge failure recovers safely; no duplicated ledger entries.

**Dependencies:** M06-M07.

**Decision rule:** Cross-world transactions require atomicity or compensating rollback.

### M09: Alpha quality and release

**Deliverable:** Long-run tests, perf benchmarks, CI, in-game usability, licensing audit, installation docs, portability, testable baseline and regressions.

**Acceptance:** No P0 accounting/identity defects; baseline comparisons for 30 matched seeds; target hardware meets a measured performance budget; publishable license inventory.

**Dependencies:** All other phases.

**Decision rule:** Public alpha only after permission and reproducibility checks.

## Ecological validation specification

1. Unit- and species-scale: balanced Book transfers; food mass and embodied energy move together; short/long-term reserves and tissue correctly support activity; delayed digestion while awake/asleep; no arbitrary time/action currency; age/size-specific development and reproduction.
2. Demographic: age/cohort sex balances, G1→G2→G3 and first independent juvenile survival for each species in physically suitable reference scenarios.
3. Trophic: calories from prey (including fat and gut), edible fraction, loss as waste/heat, carcass reuse, successful encounter rate, satiation, predator kill rate, prey growth and habitat refuge.
4. World: producer energy and material demand, sunlight/water/soil/hydrology, structural Founder funding, conservation, native-versus-bridge resident integration.
5. Multi-World: independently persistent world clocks and accounts; explicit cross-world transfers with audit and replay.
6. Stress regimen: minimum 30 matched seeds per configuration, horizons 30/180/360/720/1080 days, at least baseline versus targeted ablations; every run includes immutable source fingerprint and experimental manifest. The 30-seed program is **planned**, not represented as executed.
7. Falsification: document observed failed births, impossible food accounting, negative stocks, missing phenotype, actor identity loss, unsupported native events, or replay mismatch. Reject 'stable' claims when any required guild fails despite headline totals.

## First two-week execution backlog

- **Task WB-001**: Create one Git repo; save source fingerprints for Core145/Core151; add project license/attribution file; install pinned WorldBox + loader in disposable copy.
- **WB-002**: Build a no-op C# WorldBox plugin that logs version, Unity runtime, assembly fingerprint and loader version; test clean game save/load.
- **WB-003**: Verify read-only actor query on actual running WorldBox (ID, species, position, age, health) without state mutation; capture logs.
- **WB-004**: Create `ActorLink` schema and mapping for one animal; test detach/reload/idempotence 10 times.
- **WB-005**: Add event audit with `PREPARED / COMMITTED / REJECTED / RECONCILED` status; no actual ecology overrides yet.
- **WB-006**: Single-authority proof: intercept one narrow feeding or spawn event; ensure Book or vanilla owns it but never both. Test fail/retry/rollback.
- **WB-007**: Generate `WorldBoxCompatibilityMatrix.csv`: documented API, game version, mod loader version, validated status, failure reason, test log reference.
- **WB-008**: Return a one-page go/no-go report before attempting a multi-World system.

## Source selection and permissions

Public references listed in `PUBLIC_RESOURCE_CATALOG.csv` are not automatically safe to redistribute or bundle. Read and retain each repository's license; preserve attribution for ecological datasets. Do not share the user's third-party Minecraft resource pack publicly until creator permission is confirmed. Game assets and private installed binaries remain separate from project source.

## Evidence hierarchy

**Verified in our own runtime** (test, log, version, fingerprint) > **documented version-specific community demonstration** > **API documented without live demonstration** > **design proposal**. Store status explicitly; plans and instrumentation are never counted as implemented behavior.
