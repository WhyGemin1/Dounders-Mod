# Founders–CIV × WorldBox public research packet

- `DEVELOPMENT_ROADMAP.md` — detailed goals, architecture, milestones M00-M09, acceptance gates, tests and first sprint.
- `PUBLIC_RESOURCE_CATALOG.csv` — 23 public links grouped by activity, licensing and verification caveats.
- `MILESTONES_AND_GATES.csv` — machine-readable acceptance criteria and prerequisites.

This is a research and planning artifact, **not a playable WorldBox mod**. No multi-World or Realm tests have been run. WorldBox API capability and compatibility must be verified in the user's installed version before integration work.
