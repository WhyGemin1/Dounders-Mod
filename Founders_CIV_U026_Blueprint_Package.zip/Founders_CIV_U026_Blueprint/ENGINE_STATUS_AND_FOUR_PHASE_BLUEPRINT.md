# Founders–CIV: Unified Engine U026 Blueprint

**Project review and four-phase development cycle · 14 November 2026**  
**Proposed release:** `U026` (design candidate; **not** an implemented engine release)  
**Related adapter:** WorldBox `M06` (integration target; **not** a verified live plugin)  
**Source baseline:** `Core151` experimental + embedded WORLD-023/024, with INTEGRATION-025 as an extension-contract reference.  
**Evidence rule:** code/test behavior is distinguished from archived reports, design proposals and external game behavior. None of the attached sources prove a complete live WorldBox deployment.

## 1. Executive decision

**Founders–CIV has meaningful executable subsystems but not yet one finished, integrated engine.** The recovered packages establish a realistic path: preserve Core151's more recent physical `Book` and feeding mechanisms, integrate actual WORLD-024 Tree/social code without replacing it, and attach WorldBox only through a separately validated event/identity bridge. The priority is to make **one persistent World Tree with autonomous Founders, a viable trophic system, and physically funded fruit and Creation investments** run on one committed simulation state. A second World follows only after that vertical slice passes replay and conservation gates.

**What should not be counted as completed:** 45 passing M05 Python tests do not establish successful C# compilation; successful Tree ledger audits do not establish ecological viability; a virtual seed is not a game-spawned World; observed WorldBox nutrition is not measured chemical energy; a screenshot snapshot change is not a birth/death rate; a roadmap milestone is not installed software.

### Project-level health

| Track | Existing evidence | Status | Main obstacle |
|---|---|---|---|
| Core151 physiology and predator/prey | 13 bridge species, paired feeding/energy policy; 11/11 focused tests rerun here; 5-day smoke run reported in M06 intake audit | **Experimental executable** | Predator guild persistence, G2/G3 viability, demographic scheduler integration, calibration |
| WORLD-023/024 living Tree | Real four-habitat `CommonsWorld`, Founder stewardship, Tree harvest, mortality/collapse and 100 recorded stress scenarios | **Experimental executable** | Portable energy-bearing food, timber/soil/mineral exports, true complex food web, long-run institutional continuity |
| SOCIAL-021 / knowledge / Soul | 100 Founder agents, directional trust, learning, squads, relationships, voluntary factions, snapshots and policies | **Executable in scope; incomplete canon** | Action-energy gate review, coordination with Core151 scheduling, historical roster verification, realistic learning |
| INTEGRATION-025 compatibility | Extension SDK, deterministic scenarios, immutable observation hooks, source fingerprints; 15/15 tests rerun here | **Working reference adapter** | Nested Core151 version drift; must not copy old `ledger.py` into newer source |
| WorldBox M05 v0.5.3 | Read-only observer source, virtual SQLite fruit accounting, native JSONL importer; 45/45 Python tests rerun here | **Offline candidate** | Complete Windows C# build and actual native capture absent; dual-Book authority not reconciled |
| WorldBox integration research M00/roadmap | Native assembly audit, authority model, milestones/gates and experiment protocol | **Research and design** | Native event semantics, actor/world identity mapping, safe save/reload, conditional physical authority |
| RSW / PSW / CIV-OS institutional research | Canon and partial Social-021/knowledge prototypes included in historical WORLD packages | **Specification/limited pilot** | Model validity, governance mechanisms and source evidence; not a validated societal prediction |

**Source discipline:** the two WORLD-024 stress ZIP uploads are byte-identical. INTEGRATION-025 and Core151's embedded reference tree overlap but contain nonidentical code. `opencode-desktop-win-x64.exe` is an application binary, not an engine source package, and was not executed.

## 2. Latest measured evidence and its limits

### Core151 physiology: real improvement in one failure mode, not stability

In the archived matched 180-day runs, physiological deaths changed from **12 → 2** for seed 100001 and **10 → 1** for seed 100002 when comparing Core150 control with Core151 regulation. Yet the total live bridge population was **50 → 56** in the first seed and **44 → 43** in the second. Predator kills increased from 21 to 35 in the latter seed, and prey alive fell from 33 to 20. At day 360 under seed 100001, the default 68-animal Core151 scenario contained **zero ridge hounds, zero red foxes and zero golden jackals**. An 80-animal prey-rich sensitivity run retained six hounds and two foxes, but **no jackals**. This is a density/food-web sensitivity, **not** an isolated proof of an improved predator algorithm.

Core151's specific repair is mechanistically valuable: `unified_foraging_151.py` considers gut food, circulating fuel, stored reserves, tissue/body mass, carcass availability and legitimate effort; severe starvation now depends on bodily depletion rather than a detached starvation-debt score. Bounded tissue mobilization can support a nearby strike at a real physiological cost. The historical `--disable-regulated-foraging` control remains available, and an intraguild-risk treatment was not promoted because its outcomes were inconclusive or adverse. More testing is needed for juvenile prey access, predator density and recruiting second generations.

### WORLD-024: stewardship influences modeled survival, but does not guarantee it

WORLD-024's 100 archived runs were **10 profiles × 10 matched seeds** with different prescribed horizons, totaling 17,600 post-bootstrap cycles. All 100 finished with valid accounting, **not** 100 surviving Trees. Shared-tree survival at the recorded endpoints was: common stewardship 10/10; owner-only 0/10; faction-restricted 0/10; unmaintained 0/10; intensive harvest 5/10; dry season 9/10; disease 10/10; higher upkeep 7/10; Founder energy pressure 10/10; private-tree option 10/10 for the *common Tree*. Independent private Tree projects generally did not persist. A cooperative Tree collapsed at cycle **440** in an additional 500-cycle fixed-seed follow-up (parent Realm at 451). These are programmed-policy outcomes, not general findings about governance.

The current portable food implementation is physically incomplete: harvested food mass is stored, but chemical energy is debited from the Tree at **consumption** rather than bound to the item at **harvest**. A Tree collapse can therefore strand already harvested food. Tree construction still draws major materials from legacy source accounts. This is a direct reason to prioritize portable edible mass + embodied-energy pairs and provenance-tagged construction inputs over additional monitoring.

### M05 and WorldBox: offline integration is not game validation

M05 v0.5.3's Python test suite passes **45/45** in this review. It contains a virtual SQLite ledger, finite shared river charge, four-habitat virtual Tree, fruit harvesting, virtual creation funding, Founder digestion/recovery and imported native-event/snapshot handling. However, the WorldBox C# observer has not been independently confirmed as compiled, installed and capturing live animal events. Its separate SQLite balances cannot spend the same resources as Core151's `Book` after integration. The WorldBox-native body remains WorldBox-controlled until callback behavior, save identity and duplicate-application risks are proven manageable.

### Compatibility and reproducibility

The separate INTEGRATION-025 suite passes **15/15**. The Core151-embedded INTEGRATION-025 suite is previously reported as **14/15**, failing its static source fingerprint because the accepted newer `founders_civ/core/ledger.py` `ingest` transaction change is not in its expected modified-file set. This is a **provenance policy mismatch**, not evidence that the ingestion physics is wrong. Resolve by reviewing exact changed files, adding an approved drift declaration and preserving original baseline hashes; do not simply turn fingerprint checks off.

## 3. Canonical direction and release naming

The user's worldbuilding and implementation requirements are distinct but complementary:

- **House and Wellspring:** the persistent Founder origin and checkpoint system. The House is not reduced to an ordinary WorldBox village; the bridge may display it as a separate management layer.
- **Founders:** 100 independently motivated, learning agents with social relationships, knowledge limitations, voluntary stewardship, creations, and recoverable checkpoint state. Their intentions are not automatically successful.
- **Worlds:** persistent living environmental systems; a World Tree integrates habitats and real maintenance demands. Worlds can fail or be abandoned.
- **Creations:** mortals, organisms, structures or new Worlds researched, reviewed and **physically funded**; future creations gain independent agency rather than being guaranteed outcomes.
- **Soul/knowledge/RSW/CIV-OS:** behavioral and institutional layers built atop actual actor experiences and resource consequences. Formal canon states are not interchangeable with generic skill scores.
- **WorldBox:** the first visible execution host and source of native ecology data, not a license to create a second biology/ledger authority.

**Version policy:** `Core151`, `WORLD-024`, `INTEGRATION-025`, and bridge `M05` are *source families*, not a sequence of increasingly finished versions of the same runtime. `U026` names the proposed integration baseline. `M06` names the next WorldBox bridge compatibility/reconciliation increment. The earlier WorldBox roadmap's `M06 = two-World scheduler` is retained as a **later capability gate**, not misrepresented as already reached by merely naming the next adapter M06.

### Non-negotiable technical rules

1. One authoritative physical `Book` and one owner of each committed physical transition.
2. Time measures events and motion; it is **not** an action currency. Rest may reduce fatigue without creating energy. Food supports digestion, circulating fuel, reserves, growth and repair on physiological timescales.
3. Meaningful transfers debit and credit actual source/destination accounts, including material, chemical energy, detritus, waste/heat and fictional river creation charge as distinct typed assets. No automatic calorie-equivalence to WorldBox nutrition.
4. Founders retain freedom to propose and attempt actions. Resource insufficiency can prevent a physical construction or cause poor physical outcomes, but does not block thinking, talking, experimenting or intention by a generic action-point meter.
5. One durable actor/world/Creation identity and replay-safe event protocol. A WorldBox tick reset or reload cannot invalidate canonical lifetime continuity.
6. Preserve ecology failure, failed reproduction, predator decline, misinformation and conflicts; never hard-code survival or success to make acceptance tests pass.
7. Every promoted change has a source fingerprint, before/after behavior trace, matched controls, conservation audit, and recorded rollback.

## 4. Proposed U026 engine architecture

```text
Founder House / Wellspring / checkpoints
       |
       v
100 Founder agents --- memory, trust, knowledge, Soul states, projects
       |                                      |
       +------ research/review/proposals -----+
                         |
                         v
              COMMAND + VALIDATION BUS
              permission, resources, identity
                         |
                         v
              CORE151 AUTHORITATIVE BOOK
       materials | chemical energy | heat | water | CE/fruit
                         |
              COMMITTED WORLD STEP
                /              \
               v                v
     biological actor runtime   World Tree registry
     gut, fuel, tissue, rest     habitat ecology, reserves,
     birth, survival, traits     maintenance, fruit surplus
               \                /
                +--- event journal ---+
                         |
                  observational views
                         |
                   WorldBox M06 adapter
               C# observer + id/epoch map
                 (NO native writes initially)
```

### A. State ownership

| State | Authoritative writer in U026 | Readers / adapters |
|---|---|---|
| Canonical Founder identity, memory, goals and checkpoint | Founder registry / scheduler | UI, WorldBox panel, analysis |
| Canonical physical material, biochemical reserves and fruit charge | Core151 typed `Book` | Actor and Tree resolvers; read-only projections |
| Species life history, physiology and G2/G3 transitions for Core actors | Unified actor-ecology resolver | Founders, analytical traces, WorldBox observer |
| Four-habitat ecological state, reserves and structural integrity | WORLD-024 Tree resolver registered in unified World step | Stewardship agents and viewer |
| Social ties, research, voluntary organizations | SOCIAL-021 agent/cognition module | Founder command pipeline; institutions |
| Native vanilla animal state in the currently loaded game | WorldBox while observer-only | Shadow importer; NOT Core151 committed transfers |
| Native-to-canonical actor links and session epochs | Durable bridge registry with explicit conflict checks | Native event classifier, source archive |
| Clock, transaction order, checkpoints | One U026 commit coordinator | Per-world schedule, test runner, WorldBox view |
| Observational JSONL/SQLite journals | Adapter storage (not a spendable resource Book) | Causal analysis and debugging |

### B. Event / ledger boundary

Use a minimum event envelope:

```json
{
  "schema": "founders-event/1",
  "event_id": "world:epoch:callback-sequence:actor:kind",
  "world_id": "WORLD-0001",
  "session_id": "native-session-id",
  "reload_epoch": 4,
  "native_actor_id": "worldbox-id",
  "canonical_actor_id": null,
  "kind": "nutrition_observed",
  "source_version": "sha256-of-game-assembly",
  "source_tick": 1000,
  "payload": {},
  "status": "OBSERVED"
}
```

`OBSERVED` is not a payment receipt or proof of a hunt. The bridge records source events, validates actor and save identity, and normalizes causal clusters. `PREPARED → COMMITTED → ACKED / RECONCILED` applies only to later *authorized* Core-controlled operations and must reject duplicate/conflicting replay. Native feed/nutrition and kill/death callbacks can describe the same underlying episode and must not independently create two nutrient transfers. If native physics cannot be intercepted safely, leave it authoritative in WorldBox and reconcile by observation only.

### C. Biological energy and bodies

Represent an actor with gut contents, absorbable nutrients, circulating fuel, fat/longer-term reserves, structural tissue and body condition, fatigue/sleep pressure, injury/repair, thermal needs, age/sex/development and inherited traits where supported. Internal flows conserve mass and chemical energy with explicit sources and sinks; depletion changes *effective capability and risk*, not arbitrary time availability. Walking and thinking are not priced in fictional fixed action points. Digestion occurs over modeled physical time; rest assists recovery/repair, while ongoing metabolism still consumes real fuel. Predation depends on access, encounter, injury risk, satiation and juvenile pathways; no scripted guaranteed hunt or birth.

### D. World Trees and energy fruit

A Tree's four actual WORLD-024 habitats hold producer biomass, consumers, detritus, substrate/water and ecological conditions. **Order of operations** in a committed world step: capture external physical inputs; ecological feeding/growth and decomposition; maintenance and structural losses; allocate genuine surplus to Tree reserves; evaluate fruit production from bounded river **creation charge** plus available physical fruit matter; transfer fruits to individually identified items; allow harvesting/storage/decay via Book transactions; permit researched/peer-reviewed Creation funding. Tree/fruit energy *must not* be free: charge has a common finite source/recharge policy and fruit carries physical matter and charge until used, decayed or lost. A failed Tree need not erase already harvested portable food energy.

`CE` (creation charge) is fictional worldbuilding physics, not ATP or measured calories. The real chemical-energy and fictional CE accounts should remain separate typed assets with explicit authorized conversion (if any); river refill/replenishment must be accounted for as a boundary source, never a silent credit. Native WorldBox fruit visuals remain future, not a completed gameplay capability.

### E. Social ecology and projects

Preserve differentiated ambitions, goals, relationships, direction-specific trust, partner connections, squad history, voluntary factions, information uncertainty and research prerequisites. A Founder may observe a Tree, infer a stressor, seek peer review, organize support and propose repairs. Review and coordination change knowledge and likelihood of funding, not physical account balances. Stewardship contracts should specify voluntary acceptance, resource budget, missed duty, backups and failure handling; no fixed forced savior agent. RSW/CIV-OS hypotheses may generate bounded policies, but are research variables, not automatically validated institutional laws.

### F. Multi-World and Realm scheduling

Use one `GlobalClock` which schedules independently persistent `WorldState` entries; only one WorldBox view must be assumed visible. Each `WorldState` has one committed tick cursor, identity namespace, Tree accounts, actor cohort, random-state snapshot and durable journal. Test two Worlds stepping while only one is viewed, deterministic checkpoint resume and no double execution. Realm links and interworld transfers require atomic or compensating transactions; do not introduce them before single-World conservation and save/reload are proven.

## 5. Currently assigned engineering work (proposed ownership, not autonomous work already in progress)

| ID | Owner/workstream | Actionable assignment | Evidence/artifact | Depends on |
|---|---|---|---|---|
| P0-01 | Integration architect | Freeze source baselines; diff Core151 vs embedded INTEGRATION-025; approve exact `ledger.py` and `world_trees.py` changes | Reviewed drift manifest, compatibility matrix, hashes | Recovered ZIPs |
| P0-02 | Core151 / Book engineer | Preserve paired `ingest` physics; define atomic `CE` fruit/matter transactions inside **Core151** (not M05 SQLite) | Unit tests, typed account map, migration/replay proof | P0-01 |
| P0-03 | World Tree engineer | Repair portable food mass+energy ownership; add real four-habitat surplus/fruit funding and failure | Tree tests; balances; fruit lifecycle trace | P0-02 |
| P0-04 | Simulation architect | Reconcile two demographic schedulers and social action-energy gates with one commit clock | Clock/reload tests, Founder decision traces | P0-01/02 |
| P0-05 | WorldBox bridge engineer | Complete local M05 v0.5.3 build, plugin load and seven-hook audit on copied save; record exact binaries | Build log, game log, version hashes, event capture | User PC / WorldBox |
| P0-06 | QA/provenance | Add matched baselines, conservation and replay gates; classify claims verified/provisional | Test manifest, verdicts, regressions | P0-01..05 |
| P1-07 | Ecology researcher/engineer | Test juvenile food acquisition, prey refuge, accessible biomass and predator recruitment | Causal ablations, matched 30-seed life histories | P0-02/03 |
| P1-08 | Founder-social engineer | Add voluntary funded stewardship contracts, backups, and knowledge-limited evidence | Policy traces, contract audit, negative controls | P0-04 |
| P1-09 | Bridge + QA | Map WorldBox actor IDs across reload epochs; shadow reconcile native events without double physiology | Replay/identity report, discrepancies | P0-05 |
| P1-10 | World architect | Establish 2-World registry and independent background stepping | 360-day dual-world proof, deterministic resume | Single-World gates |
| P2-11 | World/Creation engineer | Enable funded physical Tree/fruit appearances only after vanilla write authority proven | One controlled spawn/pickup, rollback, checkpoint | P1-09/10 |
| P2-12 | RSW/CIV-OS research | Compare stewardship institutions, learned evidence and simpler policy alternatives | Preregistered predictions and falsifiers | P1-08 |

**Working policy:** these are explicit assignments for the next engineering backlog; they are not claims that a separate agent or schedule has already executed them. At each cycle handoff, assign an actual owner, status, branch, commit/source hash, and acceptance outcome.

## 6. Four-phase engine development cycle

Every cycle starts from an immutable baseline and ends with a concrete accept/reject decision. **Phases 2, 3 and 4 are mandatory**; a cycle consisting only of planning or instrumentation does not count as productive implementation.

### Phase I — Baseline, audit and causal design

**Purpose:** establish exactly which functional behavior is defective and which source version owns it. Review current failed tests and matched results; trace real call paths; select a narrowly specified functional change. Produce a written hypothesis, simplest competing explanation and falsification conditions.

**Required outputs:** `SOURCE_MANIFEST.json`; implementation diff plan; `HYPOTHESIS.md`; old-versus-new behavior trace; immutable control scenario; exact test/seed matrix; responsible owner.

**Exit gate:** source drift reviewed; one primary behavioral target; no ambiguous authority or unbounded scope. If the available sources cannot support a claim, mark it unverified rather than inventing an explanation.

### Phase II — Code implementation and actual integration

**Purpose:** change actor or ecology behavior in the true source modules. Make paired resource transfers, state migrations and scheduler interfaces work under the shared `Book`. Replace ineffective old mechanics rather than stacking independent calculators. Preserve feature-flagged controls where necessary for matched comparisons.

**Required outputs:** functioning changed code, focused tests, source diff, typed events, ledger transaction examples, rollback/migration and explicit `IMPLEMENTED`/`NOT_IMPLEMENTED` register.

**Exit gate:** targeted unit and integration tests pass; source fingerprint policy and Book audits pass; previous core controls remain reproducible. A new dashboard, data channel or proposal alone fails this gate.

### Phase III — Simulation testing and independent validation

**Purpose:** verify what the implemented change actually does. Run synthetic short checks followed by matched long-horizon tests with equal world initial state/seed. Preserve negative controls, actor death, lost Creations and Tree collapse. Keep live WorldBox verification separate from headless outcomes.

**Minimum standard for a promotion candidate:** deterministic replay, checkpoint/resume equivalence, positive/negative Book tests, no duplicate actors/transactions, meaningful causal traces, and specified demographic outcomes. When ready, run **8 pre-registered arms × 30 matched seeds**, with observations at **30, 180, 360, 720 and 1,080 days**. This represents **240 distinct arm/seed trajectories** if checkpoints are reused, not 1,200 independent runs. Run scope must be budgeted before starting; a smaller smoke trial is not the full acceptance matrix.

**Exit gate:** produce `RUN_MANIFEST.json`, source hash, `TEST_RESULTS.csv`, failures/replay trace, cost/runtime and a causal analysis distinguishing engine defects from ecologically plausible losses.

### Phase IV — Ecological analysis, promotion and next assignment

**Purpose:** interpret mechanisms instead of celebrating aggregate survival. Inspect age-structured recruitment, reproductive pathways, predator–prey encounters, juvenile food acquisition, body condition, tree fruit surplus and stewardship opportunity costs. Compare with a simpler control and explicitly report which claims were disproven, unresolved or verified.

**Required outputs:** `ECOLOGICAL_ANALYSIS.md`, `DECISION.json`, updated backlog and versioned changelog; classify each intervention **PROMOTE**, **REVISE**, **REVERT** or **RESEARCH**. Include what failed, why the failure is ecological versus engineering, and the single next most useful code change.

**Exit gate:** no promotion without mechanical gates and credible effect evidence. Record failed ecological outcomes faithfully. The next cycle starts from the decided source version, not an undocumented collection of patches.

### Suggested 8-arm experiment for the *new* U026 ecology (proposal, not prior data)

| Arm | Functional change versus same Core151 control | Mechanism to test |
|---|---|---|
| A0 | Existing Core151 default reference, feature flags frozen | Baseline persistence and failures |
| A1 | Portable food: mass+energy bound on harvest | Does stored food remain usable after Tree stress? |
| A2 | Young-actor food access and reduced encounter barriers | Is juvenile recruitment limited by reachable calories? |
| A3 | Habitat area, refuge, movement and fallback behavior | Are spatial restrictions driving mortality? |
| A4 | Reproductive pathway and parent-pair support, only when physically funded | Is second-generation survival limited by parental access/support? |
| A5 | Calibrated predator satiation and prey recruitment feedback | Are prey collapse and excessive kill rates linked to predation policy? |
| A6 | Combine A1+A2+A3+A4+A5 with no extra energy grant | Do mechanisms interact positively or produce new problems? |
| A7 | A6 under drought/seasonal stress with no protected species | Does robustness generalize beyond favorable conditions? |

These are *hypotheses* for a new series and are **not the same eight arms** as INTEGRATION-025 or M05's earlier synthetic stress package. Record absolute founding populations, age/sex cohorts, body sizes, resources, environment and initial densities for every arm. Don't interpret altered initial density as an isolated code effect.

## 7. Release acceptance and decision matrix

| Gate | Target acceptance | Present status |
|---|---|---|
| G0: source reproducibility | Pin Core151, WORLD-024, INTEGRATION-025, M05 source hashes and approve legitimate drift | **Blocked:** embedded compatibility fingerprint list |
| G1: ledger unity | One writable Core151 `Book` for fruit+chemical+material transfers; atomic replay; zero energy/matter from nothing | **Not implemented** across M05/Core151 |
| G2: one-Tree functional slice | Real WORLD-024 Tree supports Founder observe→research→funded stewardship→fruit→funded Creation | **Partial components; no end-to-end unified proof** |
| G3: body energy semantics | Digestion, storage, repair/rest, age and body change without arbitrary action-point gating | **Partial:** Core151 repaired; Founder historical gate needs review |
| G4: viable ecological cohort | Pre-registered suitable setting supports prey and predator G2/G3 life history with explicit mortality and no forced outcomes | **Not passed:** reference predators fail by day 360 |
| G5: native observer | C# build loads, seven hooks validated, sample native captures and reload identity traces | **Not independently verified** |
| G6: shadow reconciliation | Event IDs, native identities and epochs settle observations exactly once without double native effects | **Not demonstrated live** |
| G7: multi-World clock | Two Worlds each advance 360 days with one visible, same results after save/reload | **Future gate** (old roadmap M06) |
| G8: full experiment | 30 matched seeds × stated arms with all five horizons, manifest and causal analysis | **Future gate** |

**U026 release policy:** describe the first integration as `U026-alpha0` *only after* G0–G3 pass. Describe the WorldBox M06 observer as *live verified* only after G5 and G6. Do not call the project “ecologically stable” until G4 and appropriately broad G8 testing pass. Do not claim the old M06 two-World milestone until G7 passes.

## 8. Most useful immediate four-phase cycle: U026-C001

**Target behavior:** make a food or fruit produced by the *actual WORLD-024 Tree* persist as a physically funded, portable item whose stored energy remains intact after leaving the Tree, while maintaining a single Core151 Book. This closes a documented physical economy gap and creates the pathway for genuinely funded creation-energy fruit.

- **Phase I (audit):** compare Core151 `Book.ingest` contract to WORLD-024 Tree harvest/consume calls; review expected Core151 drift in `ledger.py` and `world_trees.py`; specify mass, chemical-energy and CE typed accounts, item IDs, debit sources, detritus/heat sinks and replay IDs. Record exact before-harvest Tree state.
- **Phase II (implement):** modify the *actual* WORLD-024 harvest path and Core151 Book adapter so portable food carries paired mass/energy and independent inventory identity; add fruit CE as a *separate typed resource* only after fruit matter and river charge are already accounted; remove any duplicate M05 virtual spend authority. Include migration and old-control flag.
- **Phase III (test):** consume after Tree collapse; replay harvest twice; split/merge items without energy duplication; compare Founder rest/digestion; run Tree stress and matched Core151 predator controls. Assert sum of mass and energy accounts, no negative balances or duplicate fruit. M05 WorldBox remains read-only until a live build has evidence.
- **Phase IV (analyze):** measure delayed nutrition, prey access, Tree reserve persistence and fruit production under stress; decide PROMOTE/REVISE/REVERT and identify the next code change. Do not declare stronger ecological viability if only accounting improved.

**Successful U026-C001 outcome:** one executable, reproducible Tree→portable food/fruit→Founder/Creation transaction chain under Core151, with WORLD-024 resource provenance, replay-safe IDs, and passing conservation tests. **Not part of C001:** physically spawning a World in WorldBox, solving all predators, or two-World operation.

### Immediate handoff checklist

1. Maintain a single authoritative Git working tree built from recovered Core151; archive separate older copies and their hashes without overwriting new source.
2. Reproduce focused Core151 / INTEGRATION-025 / M05 suites; fix drift manifest **with an approved declaration**.
3. Implement and test Book-funded portable food and CE fruit on the real World Tree code.
4. Keep M05 SQLite read-only as a historical experiment once Core151 owns the same assets; never simply sum balances.
5. On the user's Windows PC, produce a full C# build log, capture/version manifest and reload-tested native event journal; do not enable native metabolic writes.
6. Run the agreed matched simulation matrix and publish positive and negative effects, not only the passing tests.
7. Hand the Phase IV decision and one most useful next engineering task to the next cycle.

## 9. Scope beyond U026

**Following engine cycles:** integrate reliable autonomous stewardship contracts and knowledge-limited reasoning; eliminate conflicting social/biology schedulers; calibrate five ecological environment families (forests, grasslands, coasts, mountain ridges, swamps) from actual ecological evidence rather than biome labels; validate prey and predator G2/G3 transitions; attach WorldBox as a read-only viewport and safe input endpoint; test two independently persistent Worlds; then Realm travel, Creations and Spirits with real identity and physical-resource rules.

**RSW/CIV-OS research** stays an explicitly linked but independently falsifiable track: social trust, governance, information diffusion and institutional succession can alter Founder actions but must not secretly alter conservation or confer guaranteed Tree survival.

## 10. Source register and verification provenance

**Primary files reviewed directly in this report:**

1. `Founders_CIV_Core151_Physiology_PredatorPrey_Experimental(2).zip`: `CYCLE151_REPAIR_REPORT.md`, `START_HERE.md`, `STRESS151_MATCHED_RESULTS.csv`, `Founders_CIV_CoreCompletion151/source/src/unified_foraging_151.py`, `.../world023024/founders_civ/core/ledger.py`.
2. `Founders_CIV_WORLD_024_100_Stress_Release(1).zip`: `README_WORLD_024.md`, `docs/WORLD_024_100_RUN_REPORT.md`, `docs/SOCIAL_AGENT_SPEC_v021.md`, `docs/CANONICAL_SIMULATION_SPEC.md`, `docs/CANONICAL_SYSTEMS.md`.
3. `Founders_CIV_INTEGRATION_025_Compatibility_Release(4).zip`: `docs/INTEGRATION_025/README.md`, extension contracts, compatibility tests and manifest.
4. `FoundersCIV_WorldBox_M05_v0.5.3_FULL.zip`: `docs/ENGINEERING_REPORT.md`, `docs/CORE151_ADAPTER_CONTRACT.md`, `m05_core.py`, observer project and tests.
5. `Founders_CIV_WorldBox_Research_Roadmap(1).zip`: `DEVELOPMENT_ROADMAP.md`, `MILESTONES_AND_GATES.csv`.
6. `Founders_CIV_WorldBox_Assembly_Audit_M00(2).zip`: `WORLDBOX_SOURCE_AUDIT_M00.md`, `FOUNDER_SPACE_ARCHITECTURE_M00.md`.
7. `Founders_CIV_M06_Source_Intake_Audit.zip`: source manifest and audit of the same recovered package family.
8. `STRESS151_MATCHED_RESULTS(1).csv`: independently supplied historical matched scenario table; identical observations to bundled Core151 data.
9. `M05_to_M06_Dependency_Validation_Kit.zip`: static Unity dependency checks only; not a C# build or native gameplay record.

**Rerun in this analysis environment on 14 November 2026:** Core151 focused physiology 11/11 pass; standalone INTEGRATION-025 15/15 pass; M05 v0.5.3 Python 45/45 pass. The embedded 14/15 source-drift result and five-day core smoke-run are from the earlier M06 source-intake audit, not freshly rerun here. Historical WORLD-024 100-run results were inspected from archived release reports, not recomputed.

**Not available as verification evidence:** a successful Windows C# compilation and runtime event capture; a Core151/M05 merged and audited Book; a calibrated five-biome ecology; complete 30-seed, 1080-day acceptance for the combined engine; operational WorldBox creation fruit pickup.
