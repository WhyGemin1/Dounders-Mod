# Founders–CIV U026 Blueprint Handoff

**Dated:** 14 November 2026. **Status:** source-backed planning/assessment package, not an executable U026 engine or verified WorldBox M06 mod.

## Contents

- `Founders_CIV_U026_Engine_Blueprint.docx`: polished status assessment and detailed four-phase engineering model.
- `ENGINE_STATUS_AND_FOUR_PHASE_BLUEPRINT.md`: editable source and full reference inventory.
- `CURRENT_ASSIGNMENTS.csv`: prioritized engineering task board. `reported_status` describes current verification, not work that has been autonomously assigned or executed.
- `SOURCE_MANIFEST.json`: SHA-256 hashes and contents summary for the original source uploads used in the review.
- `FOUR_PHASE_CYCLE.json`: machine-readable cycle structure and experimental scope.
- `RUN_MANIFEST_TEMPLATE.json`: fill out for each actual simulation run.
- `DECISION_TEMPLATE.json`: fill out at the end of Phase IV.

## Most useful next task

**U026-C001:** approve Core151 source drift; implement portable food mass + embodied energy and CE fruit on the actual WORLD-024 Tree using **one Core151 Book**; run replay and conservation tests; report actual ecological effects separately from accounting correctness.

## Evidence qualifiers

The report uses the attached Core151/WORLD-024/INTEGRATION-025/M05 source and archives. In this review, 11 Core151 focused tests, 15 standalone INTEGRATION-025 tests, and 45 M05 Python tests passed. Historical WORLD-024 100-scenario and Core151 long-horizon results are archived evidence, not rerun in this document-preparation step. The C# WorldBox observer and integrated M06 gameplay remain unverified.
