#!/usr/bin/env python3
"""Static preflight for the v0.16 FACTORIAL DESIGN (does not run simulation)."""
from pathlib import Path
import csv, itertools, json, collections, hashlib
BASE=Path(__file__).resolve().parent
ST=json.loads((BASE/'Founders_CIV_v016_Factorial_Study.json').read_text())
R=list(csv.DictReader((BASE/'Founders_CIV_v016_Run_Manifest.csv').open()))
assert ST['design']['runs']==480 and len(R)==480
assert len(set(x['run_id'] for x in R))==480
assert len(set(x['paired_seed'] for x in R))==30
assert all(int(x['days'])==720 and int(x['initial_actors'])==286 for x in R)
expected={f'S{s}F{f}B{b}I{i}' for s,f,b,i in itertools.product((0,1),repeat=4)}
by=collections.defaultdict(list)
for x in R:
    by[x['paired_seed']].append(x)
    assert x['arm'] in expected
    assert x['arm']==f"S{x['social_diversity_S']}F{x['fear_logic_F']}B{x['collective_belief_B']}I{x['institutional_feedback_I']}"
for seed,arms in by.items():
    assert len(arms)==16 and {x['arm'] for x in arms}==expected
    assert len({x['exogenous_seed'] for x in arms})==1
    assert len({x['actor_seed'] for x in arms})==1
    assert len({x['internal_seed'] for x in arms})==16
assert hashlib.sha256((BASE/ST['blueprint_filename']).read_bytes()).hexdigest()==ST['blueprint_sha256']
print('PASS — 480 unique runs, 30 paired seed blocks, all 16 configurations per block, matching exogenous streams, reference blueprint hash verified.')
print('NOTE — This validates DESIGN files only. No simulation has been run.')
