# v0.18 Canon & Observatory — Release Notes

- **Preserved:** complete v0.17 integrated core behavior as the mechanical base, ledger, deterministic seeded actor choices and environmental updates.
- **Added:** structured canon register with executable-coverage labels; organized package layout; local HTTP API and sample data; animated, interactive 2D habitat map; clickable actor/habitat inspection; ecological and energy timeline; event search/filter; institution display; export; run new local simulation with S/F/B/I controls; test suite.
- **Data contract:** initial and per-day snapshots, catalogs of actors/social edges, filtered significant events, grouped institutions, final ledgers. The UI does not write to world state.
- **Corrections:** dashboard respects synthetic units and discloses XY positions as schematic. No claim to have implemented 100-Founder checkpointing, biological reproduction, advanced Soul States or the planned 480-run factorial test.
- **Work still necessary:** ecological viability and reproduction; whole-universe material chemistry; exact positions; multigenerational social transmission; robust independent governance and institutional capture; advanced magical contracts; calibrated physical/biological parameters.
