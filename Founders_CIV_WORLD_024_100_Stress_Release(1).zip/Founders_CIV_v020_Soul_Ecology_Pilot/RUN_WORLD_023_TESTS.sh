#!/bin/sh
set -e
cd "$(dirname "$0")"
python -m unittest discover -s tests -q
python -m unittest discover -s . -p 'test*.py' -q
python run_world_tree_pilot.py --seed 400 --days 120
