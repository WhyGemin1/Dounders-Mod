@echo off
cd /d "%~dp0"
py run_soul_ecology.py --seeds 40 --steps 12 --out results\my_first_soul_trial
pause
