@echo off
cd /d "%~dp0"
python -m unittest discover -s tests -q
if errorlevel 1 goto fail
python -m unittest discover -s . -p "test*.py" -q
if errorlevel 1 goto fail
echo WORLD-024 automated suites passed. To run 100 stress scenarios: python run_world024_batch.py
pause
exit /b 0
:fail
echo TEST FAILURE. No release promotion.
pause
exit /b 1
