@echo off
cd /d "%~dp0"
py -m unittest -v test_soul_ecology test_continuity_loop
pause
