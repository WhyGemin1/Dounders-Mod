@echo off
cd /d "%~dp0"
python -m unittest discover -s tests -q
if errorlevel 1 exit /b 1
python -m unittest discover -s . -p "test*.py" -q
if errorlevel 1 exit /b 1
python run_world_tree_pilot.py --seed 400 --days 120
pause
