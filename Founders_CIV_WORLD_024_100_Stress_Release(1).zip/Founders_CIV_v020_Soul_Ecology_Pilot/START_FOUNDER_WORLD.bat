@echo off
cd /d "%~dp0"
start "" "http://127.0.0.1:8765/"
python launch_founder_world.py --port 8765 --seed 400
pause
