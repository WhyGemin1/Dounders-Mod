@echo off
cd /d "%~dp0"
py -m unittest -v tests.test_four_systems
if errorlevel 1 (echo Prototype tests failed. & pause & exit /b 1)
py run_four_prototypes.py
if errorlevel 1 (echo Prototype demonstration failed. & pause & exit /b 1)
echo.
echo Results are saved in results\experimental\
pause
