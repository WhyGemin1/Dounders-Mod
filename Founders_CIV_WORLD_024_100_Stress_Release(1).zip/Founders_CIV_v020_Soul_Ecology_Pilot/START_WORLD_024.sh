#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 launch_world024.py --seed 820 --port 8766
