@echo off
cd /d "%~dp0"
echo Founders-CIV SOCIAL-021 experimental 25-seed test
python -m unittest discover -s tests -q || exit /b 1
python run_social_agents.py --seeds 25 --ticks 30 --workers 4 --out results/social_agents_25 || exit /b 1
python build_social_dashboard.py --json results/social_agents_25/demo_observatory.json --output results/social_agents_25/social_observatory.html || exit /b 1
start "" "%~dp0results\social_agents_25\social_observatory.html"
