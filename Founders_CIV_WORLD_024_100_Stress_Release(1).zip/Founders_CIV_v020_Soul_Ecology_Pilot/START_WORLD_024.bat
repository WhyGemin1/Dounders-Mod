@echo off
cd /d "%~dp0"
where python >nul 2>&1
if errorlevel 1 (
 echo Python was not found. Install Python 3.10+ and restart.
 pause
 exit /b 1
)
echo Launching Founders-CIV WORLD-024 Commons...
python launch_world024.py --seed 820 --port 8766
pause
