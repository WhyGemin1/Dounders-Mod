#!/bin/sh
cd "$(dirname "$0")"
python3 launch_founder_world.py --port 8765 --seed 400
